# -*- coding: utf-8 -*-
"""Figure_S03: Concurrent DJF Nino-3.4-PNA correlation."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from enso_shared_analysis import (
    run_single,
    save_figure,
    WARM,
    PURPLE,
)

def plot(out,ctx):
    nino_weekly = ctx["nino_weekly"]
    nino = ctx["nino"]
    n34 = ctx["n34_3m"]
    M = ctx["monthly"]
    seasonal = ctx["seasonal_nino34"]
    pdo_marjul = ctx["pdo_marjul"]
    djf_atm = pd.DataFrame(ctx["djf_atm"])
    cats = ctx["cats"]

    d12 = pd.concat([seasonal["DJF"].rename("NINO34_DJF"), djf_atm["PNA"].rename("PNA")], axis=1).dropna()
    fig, ax = plt.subplots(figsize=(8.0, 6.3))
    ax.scatter(d12.NINO34_DJF, d12.PNA, s=46, color="#6b86a5", alpha=.80,
               edgecolors="#333", linewidths=.4)
    sl, ic, r12, p12, se = stats.linregress(d12.NINO34_DJF, d12.PNA)
    xx = np.linspace(d12.NINO34_DJF.min() - .15, d12.NINO34_DJF.max() + .15, 200)
    ax.plot(xx, sl * xx + ic, color=PURPLE, lw=1.9)
    strong = d12[d12.NINO34_DJF >= 2.0]
    ax.scatter(strong.NINO34_DJF, strong.PNA, s=110, marker="*", color=WARM,
               edgecolors="k", linewidths=.6, zorder=6)
    xmax_strong = float(strong.NINO34_DJF.max()) if len(strong) else np.nan
    for yr, row in strong.iterrows():
        at_right = np.isfinite(xmax_strong) and float(row.NINO34_DJF) >= xmax_strong - 1e-12
        ax.annotate(str(int(yr)), (row.NINO34_DJF, row.PNA), textcoords="offset points",
                    xytext=(-6, 4) if at_right else (5, 4),
                    ha="right" if at_right else "left", va="bottom",
                    fontsize=7.0, fontweight="bold", color=WARM, annotation_clip=True)
    ax.margins(x=.08, y=.08)
    ax.text(.97, .97, f"R = {r12:.2f}", transform=ax.transAxes,
            ha="right", va="top", fontsize=8.2, fontweight="bold")
    from matplotlib.lines import Line2D
    s6_handles = [
        Line2D([0], [0], marker="o", color="none", markerfacecolor="#6b86a5",
               markeredgecolor="#333333", markersize=5.5, label="DJF winters"),
        Line2D([0], [0], color=PURPLE, lw=1.9, label="Linear fit"),
        Line2D([0], [0], marker="*", color="none", markerfacecolor=WARM,
               markeredgecolor="black", markersize=8, label="DJF Niño-3.4 ≥ 2.0°C"),
    ]
    ax.legend(handles=s6_handles, loc="upper left", frameon=False, fontsize=6.8,
              handlelength=1.5, borderaxespad=.25)
    ax.axhline(0, color="k", lw=.75)
    ax.axvline(0, color="k", lw=.75)
    ax.set_xlabel("DJF Niño-3.4 anomaly (°C)")
    ax.set_ylabel("DJF PNA index")
    ax.set_title("DJF Niño-3.4–PNA relationship", fontweight="bold")
    fig.tight_layout()
    save_figure(fig)


if __name__ == "__main__":
    run_single("Figure_S03", plot)
