#!/usr/bin/env python3
"""Geographical overview of six climate indices (Figure 1).

Panel (a): Niño-3.4 SST-anomaly domain, schematic northern Pacific PDO
context, and Darwin–Tahiti stations used for the Southern Oscillation Index.
Panel (b): approximate PNA action centres, reference Iceland/Azores
locations for the NAO, and the Northern Hemisphere analysis domain of the AO.
The shading and markers indicate geographical context; none represents an
empirical EOF loading field or the computation of the CPC index time series.
"""

from pathlib import Path
import os
import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
from mpl_toolkits.basemap import Basemap

OUT_DIR = Path(os.environ.get('ENSO_FIGURE_OUTPUT_DIR', str(Path(__file__).resolve().parent / 'outputs')))
BASE_NAME = 'Figure_01_Geographical_Overview'
DPI = int(os.environ.get('FIGURE_DPI', '1000'))
SAVE_SVG = True
SAVE_PDF = True
SAVE_TIFF = True

plt.rcParams.update({
    'font.family': 'serif',
    'font.serif': ['Times New Roman', 'Liberation Serif', 'DejaVu Serif'],
    'font.size': 12.7,
    'axes.unicode_minus': False,
    'pdf.fonttype': 42,
    'svg.fonttype': 'none',
    'path.simplify': True,
    'path.simplify_threshold': 0.02,
    'lines.antialiased': True,
    'patch.antialiased': True,
    'ps.fonttype': 42,
    'savefig.facecolor': 'white',
})

NAVY = '#0F2233'
LAND = '#F2F3F4'
SEA = '#EFF7FC'
GRID = '#7F99B0'
PDO_EDGE = '#145B99'
PDO_FILL = '#C4DBED'
NINO_EDGE = '#8A4A28'
NINO_FILL = '#E6CDB9'
SOI = '#E17800'
PNA = '#2B843D'
NAO = '#C83D47'
AO_EDGE = '#5E35B1'
AO_FILL = '#F0ECF8'
AO_LAND = '#F6F3FA'

DARWIN = (130.8456, -12.4634)
TAHITI = (-149.5670, -17.5400)
# Representative PNA centres of action (geographical illustration only).
PNA_CENTRES = [(-160.0, 23.0), (-160.0, 45.0), (-115.0, 52.5), (-80.0, 30.0)]
# Icelandic and Azores centres represented by approximate station locations.
NAO_ICELAND = (-22.73, 65.08)
NAO_AZORES = (-25.67, 37.74)


def to_east360(lon):
    return lon % 360.0


def lon_tick(value):
    value = value % 360.0
    if abs(value - 180.0) < 1e-10:
        return '180' + '\N{DEGREE SIGN}'
    if value > 180.0:
        return f"{int(round(360-value))}" + '\N{DEGREE SIGN}W'
    return f"{int(round(value))}" + '\N{DEGREE SIGN}E'


def lat_tick(value):
    if value == 0:
        return '0' + '\N{DEGREE SIGN}'
    return f"{abs(int(value))}" + '\N{DEGREE SIGN}' + ('N' if value > 0 else 'S')


def panel_pacific(ax):
    m = Basemap(
        projection='cyl', llcrnrlon=72, urcrnrlon=305,
        llcrnrlat=-42, urcrnrlat=72, resolution='i', ax=ax,
        suppress_ticks=False,
    )
    m.drawmapboundary(fill_color=SEA, color=NAVY, linewidth=1.18)
    ax.add_patch(Rectangle((115, 20), 145, 52, facecolor=PDO_FILL, edgecolor='none', alpha=0.82, zorder=1))
    m.fillcontinents(color=LAND, lake_color=SEA, zorder=2)
    m.drawcoastlines(color=NAVY, linewidth=0.78, zorder=4)

    xt = np.arange(90, 301, 30)
    yt = np.arange(-40, 61, 20)
    ax.set_xticks(xt)
    ax.set_xticklabels([lon_tick(v) for v in xt], fontsize=16.8, color=NAVY, fontweight='bold')
    ax.set_yticks(yt)
    ax.set_yticklabels([lat_tick(v) for v in yt], fontsize=16.8, color=NAVY, fontweight='bold')
    ax.tick_params(axis='both', which='major', length=0, pad=7, colors=NAVY)
    ax.grid(color=GRID, linestyle=(0, (2.2, 3.6)), linewidth=0.92, zorder=3)

    ax.add_patch(Rectangle((190, -5), 50, 10, facecolor=NINO_FILL, edgecolor=NINO_EDGE,
                           linewidth=1.7, alpha=0.96, zorder=6))
    ax.text(215, 0, 'Ni\u00f1o-3.4', ha='center', va='center',
            fontsize=18.2, weight='bold', color=NINO_EDGE, zorder=7)

    xd, yd = to_east360(DARWIN[0]), DARWIN[1]
    xta, yta = to_east360(TAHITI[0]), TAHITI[1]
    ax.plot([xd, xta], [yd, yta], color=SOI, linestyle=(0, (5, 4)), linewidth=1.9, zorder=6)
    ax.scatter([xd, xta], [yd, yta], s=78, marker='o', facecolor=SOI, edgecolor='white', linewidth=0.9, zorder=8)
    ax.text(xd, yd-5.2, 'Darwin', color=NAVY, weight='bold', ha='center', va='top', fontsize=16.0, zorder=8)
    ax.text(xta, yta-5.7, 'Tahiti', color=NAVY, weight='bold', ha='center', va='top', fontsize=16.0, zorder=8)
    ax.text(171, -11.7, 'SOI', color=SOI, weight='bold', fontsize=20.5, ha='center', va='center', zorder=8)

    ax.plot([120, 255], [20, 20], color=PDO_EDGE, linestyle=(0, (6, 4)), linewidth=2.0, zorder=6)
    ax.text(142, 23.1, '20' + '\N{DEGREE SIGN}N', color=PDO_EDGE, fontsize=15.4, weight='bold', ha='center', zorder=6)
    ax.text(184, 45.0, 'PDO', ha='center', va='center', color=PDO_EDGE, weight='bold', fontsize=21.0, zorder=7)

    ax.set_xlim(72, 305)
    ax.set_ylim(-42, 72)
    ax.set_aspect('equal', adjustable='box')
    ax.text(0.010, 0.988, '(a)', transform=ax.transAxes, va='top', ha='left', fontsize=20.5,
            weight='bold', color=NAVY, bbox=dict(facecolor='white', edgecolor='none', alpha=0.8, pad=1.1), zorder=10)


def panel_polar(ax):
    m = Basemap(projection='npstere', boundinglat=20, lon_0=0, round=True, resolution='i', ax=ax)
    m.drawmapboundary(fill_color=AO_FILL, color=NAVY, linewidth=1.18)
    m.fillcontinents(color=AO_LAND, lake_color=AO_FILL, zorder=2)

    m.drawparallels([40, 60, 80], color=GRID, linewidth=0.95, dashes=[2.2, 3.6], zorder=3)
    m.drawmeridians(np.arange(-180, 180, 45), color=GRID, linewidth=0.95, dashes=[2.2, 3.6], zorder=3)
    # Mark the prime meridian with a solid line.
    m.drawmeridians([0], color=NAVY, linewidth=1.55, dashes=[1, 0], zorder=5)
    m.drawcoastlines(color=NAVY, linewidth=0.78, zorder=4)

    for lon, lat in PNA_CENTRES:
        x, y = m(lon, lat)
        m.scatter(x, y, s=76, marker='o', facecolor='white', edgecolor=PNA, linewidth=1.65, zorder=8)

    for lon, lat in [NAO_ICELAND, NAO_AZORES]:
        x, y = m(lon, lat)
        m.scatter(x, y, s=76, marker='o', facecolor='white', edgecolor=NAO, linewidth=1.65, zorder=8)

    ax.text(0.30, 0.76, 'PNA', transform=ax.transAxes, color=PNA, fontsize=21.0, weight='bold', ha='center', zorder=9)
    ax.text(0.305, 0.305, 'NAO', transform=ax.transAxes, color=NAO, fontsize=21.0, weight='bold', ha='center', zorder=9)
    ax.text(0.535, 0.49, 'AO', transform=ax.transAxes, color=AO_EDGE, fontsize=21.0, weight='bold', ha='center', zorder=9)

    for lon in [180, 135, 90, 45, 0, -45, -90, -135]:
        angle = math.radians(lon)
        fx = 0.5 + 0.553 * math.sin(angle)
        fy = 0.5 - 0.553 * math.cos(angle)
        if lon == 0:
            label = '0' + '\N{DEGREE SIGN}'
        elif lon == 180:
            label = '180' + '\N{DEGREE SIGN}'
        else:
            label = str(abs(lon)) + '\N{DEGREE SIGN}' + ('E' if lon > 0 else 'W')
        ax.text(fx, fy, label, transform=ax.transAxes, fontsize=16.0, ha='center', va='center', color=NAVY, clip_on=False, zorder=10)

    ax.text(-0.12, 0.995, '(b)', transform=ax.transAxes, va='top', ha='left', fontsize=20.5, weight='bold', color=NAVY, clip_on=False)


def main():
    fig = plt.figure(figsize=(15.6, 6.0), facecolor='white')
    gs = fig.add_gridspec(1, 2, width_ratios=[2.25, 1.0], left=0.047, right=0.959, top=0.948, bottom=0.220, wspace=0.083)
    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    panel_pacific(ax_a)
    panel_polar(ax_b)

    legend_items = [
        Patch(facecolor=NINO_FILL, edgecolor=NINO_EDGE, linewidth=1.3, label='Ni\u00f1o-3.4'),
        Line2D([0], [0], marker='o', color=SOI, markerfacecolor=SOI, markersize=7.2, linewidth=1.35, linestyle=(0, (4, 3)), label='SOI'),
        Patch(facecolor=PDO_FILL, edgecolor=PDO_EDGE, linewidth=1.3, label='PDO'),
        Line2D([0], [0], marker='o', color='none', markerfacecolor='white', markeredgecolor=PNA, markeredgewidth=1.7, markersize=8.2, linestyle='None', label='PNA'),
        Line2D([0], [0], marker='o', color='none', markerfacecolor='white', markeredgecolor=NAO, markeredgewidth=1.7, markersize=8.2, linestyle='None', label='NAO'),
        Patch(facecolor=AO_FILL, edgecolor=AO_EDGE, linewidth=1.3, label='AO'),
    ]
    leg = fig.legend(handles=legend_items, ncol=6, loc='lower center',
                     bbox_to_anchor=(0.047, 0.058, 0.912, 0.100), mode='expand',
                     frameon=True, fancybox=False, handlelength=2.85, handleheight=1.20,
                     columnspacing=1.7, handletextpad=0.7, borderpad=0.74,
                     prop={'size': 16.1, 'weight': 'bold'})
    leg.get_frame().set_edgecolor(NAVY)
    leg.get_frame().set_linewidth(0.85)
    leg.get_frame().set_facecolor('white')

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    png_path = OUT_DIR / (BASE_NAME + '.png')
    pdf_path = OUT_DIR / (BASE_NAME + '.pdf')
    svg_path = OUT_DIR / (BASE_NAME + '.svg')
    tif_path = OUT_DIR / (BASE_NAME + '.tif')

    fig.savefig(png_path, dpi=DPI, facecolor='white')
    if SAVE_PDF:
        fig.savefig(pdf_path, dpi=DPI, facecolor='white')
    if SAVE_SVG:
        fig.savefig(svg_path, dpi=DPI, facecolor='white')
    if SAVE_TIFF:
        fig.savefig(tif_path, dpi=DPI, facecolor='white', pil_kwargs={'compression': 'tiff_lzw'})
        # Convert the fully opaque raster to a three-channel RGB TIFF.
        from PIL import Image
        import warnings
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore', category=Image.DecompressionBombWarning)
            with Image.open(tif_path) as image:
                rgb = image.convert('RGB')
        rgb.save(tif_path, compression='tiff_lzw', dpi=(DPI, DPI))
        rgb.close()

    plt.close(fig)
    print('Saved:', png_path)
    print('Saved:', pdf_path)
    print('Saved:', svg_path)
    print('Saved:', tif_path)


if __name__ == '__main__':
    main()
