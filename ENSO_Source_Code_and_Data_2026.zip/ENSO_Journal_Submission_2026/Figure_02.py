# -*- coding: utf-8 -*-
"""Figure_02: Nino-3.4 sea-surface temperature anomalies and SOI."""
from __future__ import annotations

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from enso_shared_analysis import (
    run_single,
    save_figure,
    _panel_title,
    WARM,
    COOL,
    ACC,
)

def plot(out,ctx):
    nino_weekly = ctx["nino_weekly"]
    nino = ctx["nino"]
    n34 = ctx["n34_3m"]
    M = ctx["monthly"]
    seasonal = ctx["seasonal_nino34"]
    pdo_marjul = ctx["pdo_marjul"]
    djf_atm = pd.DataFrame(ctx["djf_atm"])
    cats = ctx["cats"]

    fig, axes = plt.subplots(2, 1, figsize=(10.5, 7.8), sharex=True,
                             gridspec_kw={"height_ratios": [2.15, 1]})
    ax = axes[0]
    ax.axhline(0, color="k", lw=.8)
    ax.plot(nino_weekly.index, nino_weekly.values, color="#a9a9a9", lw=.45,
            alpha=.65, label="Weekly Niño-3.4")
    ax.plot(n34.index, n34.values, color="k", lw=1.7, label="3-month mean")
    ax.fill_between(n34.index, 0, n34.values, where=(n34.values > 0),
                    color=WARM, alpha=.22, interpolate=True)
    ax.fill_between(n34.index, 0, n34.values, where=(n34.values < 0),
                    color=COOL, alpha=.22, interpolate=True)

    # Label only the historical DJF winters that meet the study's >=2 C threshold.
    for djf_year, val in seasonal["DJF"].dropna().items():
        if val >= 2.0:
            developing = int(djf_year) - 1
            t = pd.Timestamp(int(djf_year), 1, 1)
            if t in n34.index:
                y = float(n34.loc[t])
                dx = -10 if int(djf_year) >= 2016 else 6
                ha = "right" if int(djf_year) >= 2016 else "left"
                ax.annotate(f"{developing}–{str(int(djf_year))[-2:]}",
                            xy=(t, y), xycoords="data",
                            xytext=(dx, 8), textcoords="offset points",
                            ha=ha, va="bottom", fontsize=7.2,
                            fontweight="bold", color=WARM,
                            annotation_clip=True)

    last = nino.index[-1]
    jja26 = float(seasonal["JJA"].loc[2026]) if 2026 in seasonal["JJA"].index and pd.notna(seasonal["JJA"].loc[2026]) else np.nan
    ax.plot([last], [float(nino.iloc[-1])], marker="*", ms=14, color=ACC,
            mec="k", mew=.6, zorder=10)
    ax.annotate(f"Aug 2026 {float(nino.iloc[-1]):+.2f}°C\nJJA {jja26:+.2f}°C",
                xy=(last, float(nino.iloc[-1])), xycoords="data",
                xytext=(.965, .92), textcoords="axes fraction",
                ha="right", va="top", fontsize=7.2, fontweight="bold", color=ACC,
                arrowprops=dict(arrowstyle="-", color=ACC, lw=.8),
                annotation_clip=True)
    ax.set_ylabel("Niño-3.4 SST anomaly (°C)")
    ax.set_ylim(-2.7, 3.6)
    ax.legend(loc="upper left", ncol=2, handlelength=2.0, columnspacing=1.2)
    _panel_title(ax, "(a) Niño-3.4 sea-surface temperature anomaly")

    ax = axes[1]
    soi = M["SOI"].dropna()
    ax.axhline(0, color="k", lw=.8)
    ax.bar(soi.index, soi.values, width=25,
           color=[COOL if v > 0 else WARM for v in soi.values], alpha=.86, linewidth=0)
    if len(soi):
        t = soi.index[-1]
        v = float(soi.iloc[-1])
        ax.plot([t], [v], marker="*", ms=13, color=ACC, mec="k", mew=.6, zorder=10)
        ax.annotate(f"{t.strftime('%b %Y')} {v:+.1f}", xy=(t, v), xycoords="data",
                    xytext=(.95, .12), textcoords="axes fraction",
                    ha="right", va="bottom", fontsize=7.2, fontweight="bold", color=ACC,
                    arrowprops=dict(arrowstyle="-", color=ACC, lw=.8),
                    annotation_clip=True)
    ax.set_ylabel("SOI (standardised)")
    ax.set_xlabel("Year")
    _panel_title(ax, "(b) Southern Oscillation Index (SOI)")
    ax.set_xlim(pd.Timestamp("1981-01-01"), pd.Timestamp("2027-06-01"))
    fig.tight_layout()
    save_figure(fig)


if __name__ == "__main__":
    run_single("Figure_02", plot)
