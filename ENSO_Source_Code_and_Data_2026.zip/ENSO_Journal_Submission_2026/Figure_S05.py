# -*- coding: utf-8 -*-
"""Figure_S05: PDO interaction regression."""
from __future__ import annotations

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from enso_shared_analysis import (
    run_single,
    save_figure,
    WARM,
    COOL,
)

def plot(out,ctx):
    nino_weekly = ctx["nino_weekly"]
    nino = ctx["nino"]
    n34 = ctx["n34_3m"]
    M = ctx["monthly"]
    seasonal = ctx["seasonal_nino34"]
    pdo_marjul = ctx["pdo_marjul"]
    djf_atm = pd.DataFrame(ctx["djf_atm"])
    cats = ctx["cats"]

    pm = out["pdo_modulation"]
    co = pm["coefficients"]
    pctx = pdo_marjul.copy()
    pctx.index = pctx.index + 1
    d13 = pd.concat([seasonal["DJF"].rename("NINO34_DJF"), pctx.rename("PDO"),
                     djf_atm["PNA"].rename("PNA")], axis=1).dropna()
    fig, ax = plt.subplots(figsize=(8.4, 6.2))
    ax.scatter(d13.NINO34_DJF, d13.PNA, s=36, color="#8b8b8b", alpha=.45)
    xgrid = np.linspace(d13.NINO34_DJF.min(), d13.NINO34_DJF.max(), 220)
    levels = [
        ("Low PDO", pm["pdo_q25"], COOL, "--", -10),
        ("Median PDO", pm["pdo_q50"], "#555", "-", 0),
        ("High PDO", pm["pdo_q75"], WARM, "-", 10),
    ]
    for lab, pv, col, ls, dy in levels:
        xc = xgrid - pm["nino34_mean"]
        pc = pv - pm["pdo_mean"]
        yhat = co["const"] + co["NINO34_c"] * xc + co["PDO_c"] * pc + co["INT"] * xc * pc
        ax.plot(xgrid, yhat, color=col, ls=ls, lw=1.9, label=lab)
    ax.scatter([], [], s=36, color="#8b8b8b", alpha=.45, label="Observed winters")
    handles, labels = ax.get_legend_handles_labels()
    # Put observations first, followed by Low / Median / High PDO fits.
    order_legend = [3, 0, 1, 2] if len(handles) >= 4 else list(range(len(handles)))
    ax.legend([handles[i] for i in order_legend], [labels[i] for i in order_legend],
              loc="upper right", frameon=False, fontsize=6.8, handlelength=1.5,
              borderaxespad=.3)
    ax.axhline(0, color="k", lw=.75)
    ax.axvline(0, color="k", lw=.75)
    ax.text(.03, .97, f"Niño-3.4×PDO p={pm['interaction_p_hac']:.3f}",
            transform=ax.transAxes, ha="left", va="top", fontsize=7.8)
    ax.set_xlabel("DJF Niño-3.4 anomaly (°C)")
    ax.set_ylabel("DJF PNA index")
    ax.set_title("Niño-3.4–PNA association by PDO level", fontweight="bold")
    fig.tight_layout()
    save_figure(fig)


if __name__ == "__main__":
    run_single("Figure_S05", plot)
