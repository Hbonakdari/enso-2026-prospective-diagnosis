# -*- coding: utf-8 -*-
"""Figure_S04: Atmospheric indices by Nino-3.4 magnitude class."""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from enso_shared_analysis import (
    run_single,
    save_figure,
    _panel_title,
    WARM,
    COOL,
)

def plot(out, ctx):
    """Plot winter circulation-index composites by Niño-3.4 magnitude."""
    cats = ctx["cats"]
    djf_atm = ctx["djf_atm"]

    fig, axes = plt.subplots(1, 3, figsize=(7.50, 3.62), sharex=True)
    order = [
        "Cold Niño-3.4", "Neutral", "Weak warm Niño-3.4",
        "Moderate warm Niño-3.4", "Strong warm Niño-3.4",
        "Very strong warm Niño-3.4",
    ]
    short = ["Cold", "Neutral", "Weak", "Moderate", "Strong", "Very\nstrong"]
    pal = [COOL, "#9a9a9a", "#d8a16f", "#c98364", "#b96555", WARM]
    rng = np.random.default_rng(42)

    for ax, k, ttl in zip(axes, ["PNA", "NAO", "AO"], ["(a) PNA", "(b) NAO", "(c) AO"]):
        panel = []
        extrema = [0.0]
        series = djf_atm[k] if isinstance(djf_atm, dict) else djf_atm[k]

        for cat in order:
            yrs = cats[cats == cat].index
            vals = series.loc[series.index.intersection(yrs)].dropna().values
            if len(vals):
                mean = float(np.mean(vals))
                sd = float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0
                extrema.extend(vals.tolist())
                extrema.extend([mean - sd, mean + sd])
            else:
                mean, sd = np.nan, 0.0
            panel.append((vals, mean, sd))

        ymin_data = float(np.nanmin(extrema))
        ymax_data = float(np.nanmax(extrema))
        span = max(ymax_data - ymin_data, 1.0)
        ylo = ymin_data - 0.075 * span
        yhi = ymax_data + 0.18 * span
        ax.set_ylim(ylo, yhi)

        yrange = yhi - ylo
        label_pad = 0.028 * yrange
        label_cap = yhi - 0.045 * yrange

        for i, ((vals, mean, sd), col) in enumerate(zip(panel, pal)):
            if len(vals) == 0:
                ax.text(i, min(0.05, label_cap), "n=0", ha="center", va="bottom",
                        fontsize=6.5, color="#777", clip_on=True, zorder=7)
                continue

            ax.bar(i, mean, color=col, width=.64, alpha=.86, linewidth=0, zorder=2)
            if len(vals) >= 2:
                ax.errorbar(i, mean, yerr=sd, fmt="none", ecolor="#333",
                            capsize=3.0, lw=0.95, zorder=4)
            jitter = rng.uniform(-.12, .12, len(vals))
            ax.scatter(i + jitter, vals, s=13, color="#555", alpha=.62,
                       zorder=5, edgecolors="none")

            top_data = max(float(np.nanmax(vals)), mean + (sd if len(vals) >= 2 else 0.0))
            label_y = min(top_data + label_pad, label_cap)
            ax.text(i, label_y, f"n={len(vals)}", ha="center", va="bottom",
                    fontsize=6.5, color="#555", clip_on=True, zorder=7)

        ax.axhline(0, color="k", lw=.70)
        ax.set_xticks(range(len(order)))
        ax.set_xticklabels(short, fontsize=6.5, rotation=32, ha="right", rotation_mode="anchor")
        ax.set_ylabel(f"DJF {k} index (standardised)", fontsize=7.2, labelpad=3)
        ax.tick_params(axis="y", labelsize=6.9, pad=2)
        ax.tick_params(axis="x", pad=2)
        _panel_title(ax, ttl)
        ax.grid(axis="y", alpha=.16)

    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    s3_handles = [
        Patch(facecolor="#999999", edgecolor="none", alpha=.86, label="Class mean"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor="#555555",
               markeredgecolor="none", markersize=4.0, label="Individual winters"),
        Line2D([0], [0], color="#333333", lw=.95, marker="|", markersize=7,
               label="±1 SD"),
    ]
    fig.legend(handles=s3_handles, loc="upper center", bbox_to_anchor=(.50, .905),
               ncol=3, frameon=False, fontsize=6.9, handlelength=1.15,
               columnspacing=1.0, handletextpad=.35)
    fig.suptitle("DJF atmospheric indices by Niño-3.4 magnitude bin",
                 fontweight="bold", fontsize=8.9, y=.985)
    fig.subplots_adjust(left=.073, right=.992, bottom=.225, top=.79, wspace=.30)
    save_figure(fig)
    plt.close(fig)


if __name__ == "__main__":
    run_single("Figure_S04", plot)
