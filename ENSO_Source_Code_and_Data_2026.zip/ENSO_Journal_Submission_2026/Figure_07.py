# -*- coding: utf-8 -*-
"""Figure_07: Winter Nino-3.4-PNA correlation robustness."""
from __future__ import annotations

import pandas as pd
import matplotlib.pyplot as plt
from enso_shared_analysis import (
    run_single,
    save_figure,
    _panel_title,
    PURPLE,
    ROBUST_BLOCK_LENGTHS,
)

def plot(out,ctx):
    nino_weekly = ctx["nino_weekly"]
    nino = ctx["nino"]
    n34 = ctx["n34_3m"]
    M = ctx["monthly"]
    seasonal = ctx["seasonal_nino34"]
    pdo_marjul = ctx["pdo_marjul"]
    djf_atm = pd.DataFrame(ctx["djf_atm"])
    cats = ctx["cats"]

    rob = out["robustness"]
    fig, axes = plt.subplots(1, 2, figsize=(11.2, 4.6))
    ax = axes[0]
    vals = [rob["full_r"], rob["exclude_1992_r"]]
    ax.bar(["All winters", "Exclude\n1991/92"], vals,
           color=[PURPLE, "#9a78bd"], width=.58)
    ax.set_ylim(0, .8)
    ax.set_ylabel("DJF Niño-3.4–PNA R")
    _panel_title(ax, "(a) Pinatubo sensitivity")
    for i, v in enumerate(vals):
        ax.text(i, v + .025, f"R={v:.2f}", ha="center", fontweight="bold", fontsize=8.0)

    ax = axes[1]
    for offset, key, label, col in [
        (-.07, "full_ci95", "All winters", PURPLE),
        (.07, "exclude_1992_ci95", "Exclude 1991/92", "#9a78bd"),
    ]:
        xs, mids, lo, hi = [], [], [], []
        for L in ROBUST_BLOCK_LENGTHS:
            ci = rob["blocks"][str(L)][key]
            mid = rob["full_r"] if key == "full_ci95" else rob["exclude_1992_r"]
            xs.append(L + offset)
            mids.append(mid)
            lo.append(mid - ci[0])
            hi.append(ci[1] - mid)
        ax.errorbar(xs, mids, yerr=[lo, hi], fmt="o", capsize=4, color=col)
    ax.axhline(0, color="k", lw=.8)
    ax.set_xticks(ROBUST_BLOCK_LENGTHS)
    ax.set_xlim(1.6, 5.28)
    ax.set_xlabel("Moving-block length (years)")
    ax.set_ylabel("Niño-3.4–PNA R")
    ax.text(5.20, rob["full_r"] + .035, "All winters", color=PURPLE,
            fontsize=7.2, va="center", ha="right", clip_on=True)
    ax.text(5.20, rob["exclude_1992_r"] - .040, "Exclude 1991/92", color="#9a78bd",
            fontsize=7.2, va="center", ha="right", clip_on=True)
    _panel_title(ax, "(b) Block-length robustness")
    fig.tight_layout()
    save_figure(fig)


if __name__ == "__main__":
    run_single("Figure_07", plot)
