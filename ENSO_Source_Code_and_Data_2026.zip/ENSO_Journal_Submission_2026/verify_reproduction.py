#!/usr/bin/env python3
"""Validate input integrity and reproduce the principal numerical diagnostics."""
from __future__ import annotations

import csv
import hashlib
from pathlib import Path
import numpy as np
from enso_shared_analysis import load_and_analyse

HERE = Path(__file__).resolve().parent


def check_close(name, found, expected, tolerance):
    if not np.isfinite(found) or abs(found - expected) > tolerance:
        raise RuntimeError(f"{name}: observed {found}; expected {expected} +/- {tolerance}")
    print(f"PASS {name}: {found:.6f}")


def main():
    names = (
        "nino34", "soi", "pdo", "pna", "nao", "ao"
    )
    for name in names:
        file = HERE / "data" / f"{name}.nc"
        if not file.is_file() or file.stat().st_size == 0:
            raise FileNotFoundError(file)
    for file in sorted(HERE.glob("Figure_*.py")):
        text_copy = file.with_suffix(".txt")
        if not text_copy.is_file() or file.read_bytes() != text_copy.read_bytes():
            raise RuntimeError(f"Code copy differs: {file.name}")
    if len(list(HERE.glob("Figure_*.py"))) != 12:
        raise RuntimeError("The figure index requires twelve Python scripts")
    print("PASS 12 Python/TXT figure-source pairs")

    out, _ = load_and_analyse(HERE / "data")
    if out["seasonal_nino34_coverage"]["DJF"][2] != 45:
        raise RuntimeError("DJF sample count is not 45")
    print("PASS completed DJF winters: 45")
    pna = out["djf_nino34_correlations"]["PNA"]
    check_close("DJF Nino-3.4-PNA r", pna["r"], 0.5616002906203806, 1e-8)
    check_close("PDO interaction coefficient", out["pdo_modulation"]["interaction_beta"], 0.04882579017731406, 1e-8)
    check_close("PDO interaction HAC p", out["pdo_modulation"]["interaction_p_hac"], 0.1743190440543239, 1e-7)
    cv = out["nino34_persistence"]["hindcast"]
    check_close("Persistence hindcast R2", cv["r2"], 0.7374294866955144, 1e-8)
    if cv["n"] != 29:
        raise RuntimeError("Persistence hindcast count is not 29")
    print("PASS persistence hindcasts: 29")
    check_close("Full-sample Figure 7 r", out["robustness"]["full_r"], 0.5616002906203806, 1e-8)
    check_close("Figure 7 r excluding 1991/92", out["robustness"]["exclude_1992_r"], 0.5560156656628377, 1e-8)
    block_lengths = {int(v) for v in out["robustness"]["blocks"]}
    if block_lengths != {2, 3, 4, 5}:
        raise RuntimeError("Unexpected bootstrap block lengths")
    print("PASS bootstrap lengths: 2, 3, 4, 5 years")
    check_close("PNA seasonal circular-shift FDR", out["seasonal_lead_correlations"]["PNA"]["DJF(0)"]["q_fdr9_circular"], 0.06818181818181819, 1e-10)
    print("Numerical verification completed")


if __name__ == "__main__":
    main()
