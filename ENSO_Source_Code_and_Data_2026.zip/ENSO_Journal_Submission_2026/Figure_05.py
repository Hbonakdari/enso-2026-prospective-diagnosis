# -*- coding: utf-8 -*-
"""Figure_05: Circulation-index correlations and PDO-stratified relationships."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib.lines import Line2D
from enso_shared_analysis import (
    run_single,
    save_figure,
    _apply_publication_style,
    WARM,
    COOL,
    GREEN,
    PURPLE,
    BROWN,
)

def plot(out, ctx):
    """Plot monthly, seasonal and PDO-conditioned teleconnections."""
    _apply_publication_style()
    seasonal = ctx["seasonal_nino34"]
    pdo_marjul = ctx["pdo_marjul"]
    djf_atm = pd.DataFrame(ctx["djf_atm"])

    fig = plt.figure(figsize=(7.50, 2.88))
    gs = fig.add_gridspec(
        1, 3,
        width_ratios=[1.04, 1.00, 1.17],
        left=.072, right=.992, bottom=.205, top=.885,
        wspace=.40
    )
    axes = [fig.add_subplot(gs[0, i]) for i in range(3)]

    for ax in axes:
        ax.tick_params(axis='both', labelsize=7.5, width=.75, length=3.0, pad=2.2)
        for sp in ax.spines.values():
            sp.set_linewidth(.8)

    # (a) Monthly lag correlations
    lags = np.arange(-6, 7)
    ax = axes[0]
    end_labels = []
    for k, col in [("PNA", PURPLE), ("NAO", GREEN), ("AO", BROWN)]:
        vals = np.array([out["monthly_lag_correlations"][k][str(int(l))]["r"] for l in lags], float)
        ax.plot(lags, vals, marker="o", ms=2.55, lw=1.25, color=col)
        for l, v in zip(lags, vals):
            q = out["monthly_lag_correlations"][k][str(int(l))].get("q_fdr39", np.nan)
            if np.isfinite(q) and q < .05:
                ax.scatter([l], [v], s=36, facecolors="white", edgecolors=col,
                           linewidths=1.05, zorder=7)
        end_labels.append((k, col, float(vals[-1])))
    ax.axhline(0, color="k", lw=.65)
    ax.axvline(0, color="#777", lw=.65, ls="--")
    ax.set_xticks(lags)

    # Right-hand margin for endpoint labels.
    ax.set_xlim(-6.35, 8.20)

    # Separate overlapping endpoint labels.
    ylo, yhi = ax.get_ylim()
    yrng = max(yhi - ylo, 1e-9)
    min_gap = 0.075 * yrng
    ordered = sorted(end_labels, key=lambda item: item[2])
    placed = []
    for k, col, yv in ordered:
        yp = float(yv)
        if placed and yp - placed[-1][3] < min_gap:
            yp = placed[-1][3] + min_gap
        placed.append([k, col, yv, yp])

    # Keep labels within the plot bounds.
    top_allowed = yhi - 0.045 * yrng
    if placed and placed[-1][3] > top_allowed:
        shift = placed[-1][3] - top_allowed
        for item in placed:
            item[3] -= shift

    bottom_allowed = ylo + 0.045 * yrng
    if placed and placed[0][3] < bottom_allowed:
        shift = bottom_allowed - placed[0][3]
        for item in placed:
            item[3] += shift

    for k, col, yv, yp in placed:
        ax.text(
            6.18, yp, k,
            color=col, fontsize=6.1, fontweight="bold",
            va="center", ha="left", clip_on=True, zorder=9,
            path_effects=[pe.withStroke(linewidth=1.35, foreground="white")],
        )

    ax.set_xlabel("Lag (months; + = atmosphere follows)", fontsize=8.0, labelpad=3.5)
    ax.set_ylabel("Pearson R", fontsize=8.0, labelpad=4)
    ax.set_title("(a) Monthly lag correlations", loc="left",
                 fontsize=8.8, fontweight="bold", pad=4.2)

    # (b) Seasonal predictors
    ax = axes[1]
    seasons = ["JJA(-1)", "SON(-1)", "DJF(0)"]
    xpos = np.arange(3)
    width = .22
    first_group_labels = []
    for j, (k, col) in enumerate([("PNA", PURPLE), ("NAO", GREEN), ("AO", BROWN)]):
        vals = [out["seasonal_lead_correlations"][k][ss]["r"] for ss in seasons]
        xxbar = xpos + (j - 1) * width
        ax.bar(xxbar, vals, width, color=col, alpha=.86)
        first_group_labels.append((xxbar[0], vals[0], k, col))
    ax.axhline(0, color="k", lw=.65)
    ax.set_xticks(xpos)
    ax.set_xticklabels(["JJA\n(-6 mo)", "SON\n(-3 mo)", "DJF\n(0 mo)"], fontsize=7.0)
    ax.set_ylabel("Pearson R with following DJF index", fontsize=7.8, labelpad=3)
    ax.set_ylim(-.205, .635)

    # Direct labels for seasonal predictor groups.
    x_offsets = {"PNA": -0.012, "NAO": 0.000, "AO": 0.012}
    for xb, yb, lab, col in first_group_labels:
        if yb >= 0:
            yt, va = min(yb + .016, .610), "bottom"
        else:
            yt, va = max(yb - .018, -.165), "bottom"
        ax.text(
            xb + x_offsets.get(lab, 0.0), yt, lab,
            ha="center", va=va, fontsize=6.1, fontweight="bold", color=col,
            clip_on=True, zorder=8,
            path_effects=[pe.withStroke(linewidth=1.6, foreground="white")],
        )
    ax.set_title("(b) Seasonal Niño-3.4 predictors", loc="left",
                 fontsize=8.8, fontweight="bold", pad=4.2)

    # (c) PDO modulation
    ax = axes[2]
    pctx = pdo_marjul.copy()
    pctx.index = pctx.index + 1
    d = pd.concat([seasonal["DJF"].rename("NINO34_DJF"),
                   pctx.rename("PDO"), djf_atm["PNA"].rename("PNA")],
                  axis=1, sort=False).dropna()
    for mask, col, mk, lab, ls in [
        (d.PDO > 0, WARM, "o", "PDO > 0", "-"),
        (d.PDO <= 0, COOL, "D", "PDO ≤ 0", "--"),
    ]:
        z = d[mask]
        ax.scatter(z.NINO34_DJF, z.PNA, s=24, color=col, marker=mk, alpha=.72,
                   edgecolors="#333", linewidths=.35, zorder=4)
        if len(z) >= 3:
            sl, ic, r, p, se = stats.linregress(z.NINO34_DJF, z.PNA)
            xx = np.linspace(d.NINO34_DJF.min(), d.NINO34_DJF.max(), 100)
            yy = sl * xx + ic
            ax.plot(xx, yy, color=col, lw=1.25, ls=ls, zorder=5)
    sl, ic, rall, p, se = stats.linregress(d.NINO34_DJF, d.PNA)
    xx = np.linspace(d.NINO34_DJF.min(), d.NINO34_DJF.max(), 100)
    yy = sl * xx + ic
    ax.plot(xx, yy, "k:", lw=1.05, zorder=5)
    ax.axhline(0, color="k", lw=.60)
    ax.axvline(0, color="k", lw=.60)
    pm = out["pdo_modulation"]

    ax.set_ylim(-.82, 1.92)
    ax.text(.035, .965,
            f"PDO>0 R={pm['r_nino34_pna_pdo_positive']:.2f}\n"
            f"PDO≤0 R={pm['r_nino34_pna_pdo_nonpositive']:.2f}\n"
            f"p={pm['interaction_p_hac']:.3f}",
            transform=ax.transAxes, ha="left", va="top", fontsize=6.3,
            path_effects=[pe.withStroke(linewidth=1.8, foreground="white")],
            bbox=dict(facecolor="white", edgecolor="none", alpha=.91, pad=1.6))

    xmin = float(d.NINO34_DJF.min())
    xmax = float(d.NINO34_DJF.max())
    span = xmax - xmin
    ax.set_xlim(xmin - .04 * span, xmax + .05 * span)

    # PDO-stratified fits and reference regression.
    handles = [
        Line2D([0], [0], color=WARM, marker="o", lw=1.25, ls="-", markersize=4.2,
               markerfacecolor=WARM, markeredgecolor="#333", markeredgewidth=.35, label="PDO > 0"),
        Line2D([0], [0], color="k", lw=1.05, ls=":", label="All"),
        Line2D([0], [0], color=COOL, marker="D", lw=1.25, ls="--", markersize=4.2,
               markerfacecolor=COOL, markeredgecolor="#333", markeredgewidth=.35, label="PDO ≤ 0"),
    ]
    ax.legend(
        handles=handles, loc="lower right", bbox_to_anchor=(.995, .018),
        frameon=False, fontsize=6.0, handlelength=1.20, handletextpad=.28,
        borderaxespad=.10, labelspacing=.12, markerscale=.72,
    )

    ax.set_xlabel("DJF Niño-3.4 anomaly (°C)", fontsize=8.0, labelpad=3.5)
    ax.set_ylabel("DJF PNA index", fontsize=8.0, labelpad=4)
    ax.set_title("(c) PDO modulation of Niño-3.4–PNA", loc="left",
                 fontsize=8.8, fontweight="bold", pad=4.2)

    save_figure(fig)


if __name__ == "__main__":
    run_single("Figure_05", plot)
