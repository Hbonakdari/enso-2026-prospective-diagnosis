# -*- coding: utf-8 -*-
"""Figure_04: Pacific Decadal Oscillation and Nino-3.4/PDO phase space."""
from __future__ import annotations

import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
from enso_shared_analysis import (
    run_single,
    save_figure,
    _panel_title,
    WARM,
    COOL,
    ACC,
)

def plot(out,ctx):
    nino_weekly = ctx["nino_weekly"]
    nino = ctx["nino"]
    n34 = ctx["n34_3m"]
    M = ctx["monthly"]
    seasonal = ctx["seasonal_nino34"]
    pdo_marjul = ctx["pdo_marjul"]
    djf_atm = pd.DataFrame(ctx["djf_atm"])
    cats = ctx["cats"]

    fig, axes = plt.subplots(1, 2, figsize=(12.0, 5.0),
                             gridspec_kw={"width_ratios": [1.35, 1]})
    ax = axes[0]
    p = M["PDO"][M["PDO"].index >= pd.Timestamp("1950-01-01")].dropna()
    ax.axhline(0, color="k", lw=.8)
    ax.bar(p.index, p.values, width=28,
           color=[WARM if v > 0 else COOL for v in p.values], alpha=.70, linewidth=0)
    sm = p.rolling(25, center=True, min_periods=13).mean()
    ax.plot(sm.index, sm.values, color="k", lw=1.6)
    for yr in [1982, 1991, 1997, 2015]:
        t = pd.Timestamp(yr, 7, 1)
        if t in p.index:
            ax.annotate(str(yr), xy=(t, float(p.loc[t])), xycoords="data",
                        xytext=(0, 8), textcoords="offset points",
                        ha="center", va="bottom", fontsize=7.2,
                        fontweight="bold", color="#555555", annotation_clip=True)
    t = pd.Timestamp(2026, 7, 1)
    if t in p.index:
        v = float(p.loc[t])
        ax.plot([t], [v], marker="*", ms=14, color=ACC, mec="k", mew=.6, zorder=10)
        ax.annotate(f"Jul 2026\n{v:+.2f}", xy=(t, v), xycoords="data",
                    xytext=(-8, -15), textcoords="offset points",
                    ha="right", va="top", fontsize=7.1, fontweight="bold", color=ACC,
                    annotation_clip=True)
    ax.set_ylim(-4.5, 4.2)
    ax.set_ylabel("PDO index")
    ax.set_xlabel("Year")
    _panel_title(ax, "(a) Pacific Decadal Oscillation, 1950–2026")

    ax = axes[1]
    J = pd.concat([n34.rename("NINO34_3M"), M["PDO"].rename("PDO")], axis=1, sort=True).dropna()
    J = J[J.index >= pd.Timestamp("1981-01-01")]
    ax.scatter(J.NINO34_3M, J.PDO, s=14, color="#9fb8cc", alpha=.50, edgecolors="none")
    for yr in [1982, 1991, 1997, 2015]:
        t = pd.Timestamp(yr, 7, 1)
        if t in J.index:
            ax.scatter(J.loc[t, "NINO34_3M"], J.loc[t, "PDO"], s=88,
                       color="#666666", edgecolors="k", linewidths=.5, zorder=7)
            ax.annotate(str(yr), (J.loc[t, "NINO34_3M"], J.loc[t, "PDO"]),
                        textcoords="offset points", xytext=(5, 5), fontsize=7.2,
                        fontweight="bold", color="#555555")
    tr = J[(J.index >= pd.Timestamp("2026-01-01")) & (J.index <= pd.Timestamp("2026-07-01"))]
    ax.plot(tr.NINO34_3M, tr.PDO, color=ACC, lw=2.0, marker="o", ms=4.2, zorder=8)
    if len(tr):
        ax.scatter(tr.NINO34_3M.iloc[-1], tr.PDO.iloc[-1], s=175, marker="*",
                   color=ACC, edgecolors="k", linewidths=.7, zorder=9)
        ax.annotate("Jul 2026", (tr.NINO34_3M.iloc[-1], tr.PDO.iloc[-1]),
                    textcoords="offset points", xytext=(-6, -14), ha="right", va="top",
                    color=ACC, fontweight="bold", fontsize=7.0, annotation_clip=True)
    ax.axhline(0, color="k", lw=.8)
    ax.axvline(0, color="k", lw=.8)
    rr = stats.pearsonr(J.NINO34_3M, J.PDO)[0]
    ax.text(.03, .97, f"R = {rr:+.2f}", transform=ax.transAxes,
            ha="left", va="top", fontsize=8.0, fontweight="bold")
    ax.set_xlabel("3-month Niño-3.4 anomaly (°C)")
    ax.set_ylabel("PDO index")
    _panel_title(ax, "(b) Niño-3.4–PDO phase space")
    fig.tight_layout()
    save_figure(fig)


if __name__ == "__main__":
    run_single("Figure_04", plot)
