# -*- coding: utf-8 -*-
"""Figure_03: Event-development trajectories and March-August change."""
from __future__ import annotations

import pandas as pd
import matplotlib.pyplot as plt
from enso_shared_analysis import (
    run_single,
    save_figure,
    _panel_title,
    ACC,
)

def plot(out,ctx):
    nino_weekly = ctx["nino_weekly"]
    nino = ctx["nino"]
    n34 = ctx["n34_3m"]
    M = ctx["monthly"]
    seasonal = ctx["seasonal_nino34"]
    pdo_marjul = ctx["pdo_marjul"]
    djf_atm = pd.DataFrame(ctx["djf_atm"])
    cats = ctx["cats"]

    fig, axes = plt.subplots(1, 2, figsize=(12.0, 5.2),
                             gridspec_kw={"width_ratios": [1.35, 1]})
    ax = axes[0]
    refs = [1982, 1991, 1997, 2015, 2026]
    hist_styles = {
        1982: ("#4d4d4d", "-"),
        1991: ("#6f6f6f", "--"),
        1997: ("#8a8a8a", "-."),
        2015: ("#555555", ":"),
    }
    label_offsets = {1982: (-6, 8), 1991: (-6, -9), 1997: (-6, 8), 2015: (-6, -10), 2026: (-8, 8)}
    for yr in refs:
        xs, ys = [], []
        for i in range(15):
            t = pd.Timestamp(yr, 1, 1) + pd.DateOffset(months=i)
            if t in nino.index:
                xs.append(i)
                ys.append(float(nino.loc[t]))
        if not xs:
            continue
        if yr == 2026:
            col, ls, lw, mk, ms = ACC, "-", 2.5, "*", 8.2
        else:
            col, ls = hist_styles[yr]
            lw, mk, ms = 1.35, "o", 3.2
        ax.plot(xs, ys, color=col, ls=ls, lw=lw, marker=mk, ms=ms,
                zorder=7 if yr == 2026 else 4,
                mec="k" if yr == 2026 else "none", mew=.45)
        # Direct labels are placed at different months to avoid a crowded cluster at the right edge.
        label_idx = {1982: 11, 1991: 12, 1997: 10, 2015: 10, 2026: 7}.get(yr, len(xs)-1)
        label_idx = min(label_idx, len(xs)-1)
        dx, dy = label_offsets[yr]
        lab = "2026–27" if yr == 2026 else str(yr)
        ax.annotate(lab, xy=(xs[label_idx], ys[label_idx]), xycoords="data",
                    xytext=(dx, dy), textcoords="offset points",
                    ha="right" if yr == 2026 else "left", va="center", fontsize=7.1,
                    fontweight="bold" if yr == 2026 else "normal",
                    color=col, annotation_clip=True)
    ax.axhline(0, color="k", lw=.8)
    ax.axvspan(2, 7, color="#dddddd", alpha=.42, zorder=0)
    mon = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan$^{+}$", "Feb$^{+}$", "Mar$^{+}$"]
    ax.set_xticks(range(15))
    ax.set_xticklabels(mon, rotation=90)
    ax.set_ylabel("Niño-3.4 SST anomaly (°C)")
    ax.set_xlabel("Month of developing year ($^{+}$ = following year)")
    ax.set_ylim(-1.3, 3.15)
    _panel_title(ax, "(a) Development trajectories")

    ax = axes[1]
    onset = out["onset"]
    g = pd.Series({int(y): d["delta"] for y, d in onset.items()}).sort_values()
    colbar = [ACC if y == 2026 else ("#666666" if y in [1982, 1991, 1997, 2015] else "#b8b8b8") for y in g.index]
    ax.barh(range(len(g)), g.values, color=colbar, height=.78, linewidth=0)
    ax.axvline(0, color="k", lw=.8)
    ax.set_yticks([])
    pos = {y: i for i, y in enumerate(g.index)}
    # Leave deliberate right-side headroom so the highlighted 2026 year label
    # can sit next to the orange bar rather than on top of the bar.
    xmin, xmax = ax.get_xlim()
    if 2026 in g.index and float(g.loc[2026]) >= 0:
        xmax = max(xmax, float(g.loc[2026]) + 0.16 * max(1.0, abs(float(g.loc[2026]))))
    ax.set_xlim(xmin, xmax)

    for y in [1982, 1991, 1997, 2015, 2026]:
        if y in g.index:
            xv = float(g.loc[y])
            if y == 2026:
                # Keep the 2026 label immediately outside the orange bar end.
                dx, ha, fs = 5, "left", 6.8
            else:
                near_right_edge = xv >= 0.97 * float(g.max())
                dx = -4 if near_right_edge else (4 if xv >= 0 else -4)
                ha = "right" if near_right_edge else ("left" if xv >= 0 else "right")
                fs = 7.4
            ax.annotate(str(y), xy=(xv, pos[y]), xycoords="data",
                        xytext=(dx, 0), textcoords="offset points",
                        va="center", ha=ha, fontsize=fs,
                        fontweight="bold", color=ACC if y == 2026 else "#555555",
                        annotation_clip=True)
    z = onset[2026]
    ax.text(.03, .97,
            f"2026: rank {z['delta_rank_desc']}/{z['n_years']}\nΔ={z['delta']:+.2f}°C; slope={z['slope']:+.2f}°C month$^{-1}$",
            transform=ax.transAxes, ha="left", va="top", fontsize=7.8,
            fontweight="bold", color=ACC)
    ax.set_xlabel("March-to-August change in Niño-3.4 SSTA (°C)")
    _panel_title(ax, "(b) March-to-August growth ranking")
    fig.tight_layout()
    save_figure(fig)


if __name__ == "__main__":
    run_single("Figure_03", plot)
