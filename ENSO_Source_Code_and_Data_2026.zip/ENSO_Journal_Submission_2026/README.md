# ENSO figure reproduction package

Python source code and input climate-index time series for Figures 1-7 and
Supplementary Figures S1-S5 of the associated manuscript.

## Files

- `Figure_01_Geographical_Overview.py` draws the schematic index geography.
- `Figure_02.py` through `Figure_07.py` reproduce the six remaining main figures.
- `Figure_S01.py` through `Figure_S05.py` reproduce five supplementary figures.
- Each figure script has an identical `.txt` copy for text-only submission systems.
- `enso_shared_analysis.py` contains the common climate-index processing and statistical methods.
- `run_all_figures.py` produces all 12 figures and a JSON record of the calculated statistics.
- `data/` contains six unmodified NetCDF time series; original metadata are retained.
- `FIGURE_INDEX.csv` maps the scripts to the manuscript figure numbers.
- `SHA256SUMS.txt` records file checksums; `environment_versions.txt` records tested software versions.
- `DATA_INVENTORY.csv` records input coverage, original NetCDF descriptions and hashes.
- `verify_reproduction.py` validates code copies and central numerical diagnostics.

## Software

Tested with Python 3.13.5 (see `environment_versions.txt` for package versions).
Install requirements in an isolated environment:

```bash
python -m pip install -r requirements.txt
```

## Reproduction

From the package directory:

```bash
python run_all_figures.py
python verify_reproduction.py
```

This saves all 12 figures to `outputs/`. Figure 1 is exported as PDF, SVG,
PNG, and a losslessly compressed RGB TIFF at 1000 dpi. All other figures
are exported as PDF and losslessly compressed TIFF at 900 dpi. PDFs retain
vector graphics and embedded fonts.

Run a single figure:

```bash
python Figure_01_Geographical_Overview.py
python Figure_05.py
```

The 11 climate-index figure scripts support the options `--data`, `--output`
and `--dpi`. The combined driver supports `--data`, `--output`, `--dpi`
and `--figure1-dpi`. For a fast visual test:

```bash
python run_all_figures.py --dpi 150 --figure1-dpi 150
```

## Methods and interpretation

Weekly Nino-3.4 observations are interpolated to a daily grid and averaged
to calendar months. JJA, SON and DJF seasonal means use these monthly values;
DJF is indexed by the January/February year. The monthly lead-lag predictor
is a trailing three-month mean (no subsequent-month leakage). Seasonal
correlations use 20,000 two-sided block permutations, three-year blocks,
and Benjamini-Hochberg FDR adjustment over nine tests. Circular-shift
significance tests are also calculated. The DJF Nino-3.4/PNA robustness
analysis uses circular block bootstrap intervals (10,000 replications per
block length and dataset, block lengths 2-5 years). The interaction model
uses HAC standard errors; persistence performance is evaluated with an
expanding training window.

Figure 1 provides geographical context, not estimated spatial EOF loadings.
The PDO and AO regions and the PNA/NAO locations shown in Figure 1 are
schematic. The other figures use the original climate-index NetCDF series.
The seasonal magnitude bins in Supplementary Figure S4 are descriptive
and do not define official ENSO episodes. The hydroclimatic context is not
an event-specific observation or forecast of regional hydroclimate.

The figure scripts reproduce the reported visualizations from the data
provided, subject to the software versions and figure settings above.
