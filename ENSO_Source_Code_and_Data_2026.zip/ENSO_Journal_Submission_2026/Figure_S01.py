# -*- coding: utf-8 -*-
"""Figure_S01: Recent climate-index time series."""
from __future__ import annotations

import pandas as pd
import matplotlib.pyplot as plt
from enso_shared_analysis import (
    run_single,
    save_figure,
    WARM,
    COOL,
    ACC,
    GREEN,
    PURPLE,
    BROWN,
)

def plot(out,ctx):
    nino_weekly = ctx["nino_weekly"]
    nino = ctx["nino"]
    n34 = ctx["n34_3m"]
    M = ctx["monthly"]
    seasonal = ctx["seasonal_nino34"]
    pdo_marjul = ctx["pdo_marjul"]
    djf_atm = pd.DataFrame(ctx["djf_atm"])
    cats = ctx["cats"]

    import matplotlib.dates as mdates
    t0 = pd.Timestamp("2024-01-01")
    panels = [
        ("NINO34", "Niño-3.4 SSTA (°C)", WARM, nino),
        ("SOI", "SOI (std.)", ACC, M["SOI"]),
        ("PDO", "PDO index", COOL, M["PDO"]),
        ("PNA", "PNA index (std.)", PURPLE, M["PNA"]),
        ("NAO", "NAO index (std.)", GREEN, M["NAO"]),
        ("AO", "AO index (std.)", BROWN, M["AO"]),
    ]
    latest_by_index = {nm: sr.dropna().index.max() for nm, lab, col, sr in panels if len(sr.dropna())}
    latest_overall = max(latest_by_index.values())
    t1 = (latest_overall + pd.offsets.MonthBegin(1)).normalize()

    fig, axes = plt.subplots(6, 1, figsize=(8.8, 10.2), sharex=True)
    for ax, (nm, lab, col, sr) in zip(axes, panels):
        z = sr[(sr.index >= t0) & (sr.index < t1)].dropna()
        ax.axhline(0, color="k", lw=.7)
        ax.bar(z.index, z.values, width=22, color=col, alpha=.46, linewidth=0)
        ax.plot(z.index, z.values, color=col, lw=1.45, marker="o", ms=2.8)
        if nm == "NINO34":
            zz = n34[(n34.index >= t0) & (n34.index < t1)].dropna()
            ax.plot(zz.index, zz.values, "k--", lw=1.35, label="3-month Niño-3.4 mean")
            ax.plot([], [], color=col, lw=1.45, marker="o", ms=2.8, label="Monthly Niño-3.4")
            ax.legend(loc="upper left", ncol=2, frameon=False, fontsize=6.6,
                      handlelength=1.5, columnspacing=.8)
        if len(z):
            shade_end = min(t1, (z.index.max() + pd.offsets.MonthBegin(1)).normalize())
            if shade_end > pd.Timestamp("2026-03-01"):
                ax.axvspan(pd.Timestamp("2026-03-01"), shade_end, color="#f2dfc3", alpha=.32, zorder=0)
        ax.set_ylabel(lab, fontsize=8.7)
        ax.margins(y=.16)
    axes[-1].xaxis.set_major_locator(mdates.MonthLocator(interval=6))
    axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%b\n%Y"))
    axes[-1].set_xlabel("Month")
    fig.suptitle("Climate-index evolution, 2024–2026", fontweight="bold", fontsize=11.8, y=.995)
    fig.tight_layout(rect=[0, 0, 1, .985])
    save_figure(fig)


if __name__ == "__main__":
    run_single("Figure_S01", plot)
