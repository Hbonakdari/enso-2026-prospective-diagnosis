# -*- coding: utf-8 -*-
"""Generate Figures 1-7 and Supplementary Figures S1-S5."""
from __future__ import annotations
import argparse
import importlib
from pathlib import Path
import enso_shared_analysis as analysis
import os
import subprocess
import sys
import json

FIGURES = (
    "Figure_02", "Figure_03", "Figure_04", "Figure_05", "Figure_06", "Figure_07",
    "Figure_S01", "Figure_S02", "Figure_S03", "Figure_S04", "Figure_S05",
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    base = Path(__file__).resolve().parent
    parser.add_argument("--data", type=Path, default=base / "data")
    parser.add_argument("--output", type=Path, default=base / "outputs")
    parser.add_argument("--dpi", type=int, default=900)
    parser.add_argument("--figure1-dpi", type=int, default=1000)
    args = parser.parse_args()
    if not 100 <= args.dpi <= 1200 or not 100 <= args.figure1_dpi <= 1200:
        parser.error("--dpi and --figure1-dpi must be between 100 and 1200")

    analysis.DPI = args.dpi
    analysis.FIGURE_DIR = args.output.resolve()
    analysis.FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    # Run the geographic map in a separate process to isolate map dependencies.
    env = os.environ.copy()
    env['FIGURE_DPI'] = str(args.figure1_dpi)
    env['ENSO_FIGURE_OUTPUT_DIR'] = str(analysis.FIGURE_DIR)
    subprocess.run([sys.executable, str(base / 'Figure_01_Geographical_Overview.py')],
                   env=env, check=True)
    results, context = analysis.load_and_analyse(args.data)
    (analysis.FIGURE_DIR / 'analysis_results.json').write_text(
        json.dumps(results, indent=2, ensure_ascii=False, default=float), encoding='utf-8'
    )
    analysis._apply_publication_style()
    for label in FIGURES:
        analysis.FIGURE_LABEL = label
        module = importlib.import_module(label)
        module.plot(results, context)
    print(f"Saved {len(FIGURES) + 1} figures to {analysis.FIGURE_DIR}")


if __name__ == "__main__":
    main()
