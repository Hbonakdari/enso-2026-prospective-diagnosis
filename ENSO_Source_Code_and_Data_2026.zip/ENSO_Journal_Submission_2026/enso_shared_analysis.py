# -*- coding: utf-8 -*-
"""Climate-index processing and statistical methods for figures 2–7 and S1–S5."""
from __future__ import annotations
import json
import os
import shutil
import tempfile
from pathlib import Path
import numpy as np
import pandas as pd
import xarray as xr
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib.lines import Line2D

HERE = Path(__file__).resolve().parent
INPUT_DIR = HERE / "data"
FIGURE_DIR = HERE / "outputs"
RNG_SEED = 42
N_BLOCK_PERM = 20000
N_BOOT = 10000
ROBUST_BLOCK_LENGTHS = [2, 3, 4, 5]
PINATUBO_DJF_LABEL_YEAR = 1992
DPI = 900
FIGURE_LABEL = "Unspecified_Figure"

def clean_series(s: pd.Series) -> pd.Series:
    s = pd.Series(s).astype(float).replace([np.inf, -np.inf], np.nan).dropna()
    s = s[~s.index.duplicated(keep="first")].sort_index()
    return s


def _parse_time_numeric(values, units, calendar="standard"):
    tmp = xr.Dataset(coords={"time": ("time", values, {"units": units, "calendar": calendar})})
    try:
        dec = xr.decode_cf(tmp)["time"].values
        return pd.to_datetime(dec)
    except Exception:
        units_l = str(units).lower()
        if " since " not in units_l:
            raise ValueError(f"Cannot decode time units: {units}")
        unit_name, origin = str(units).split(" since ", 1)
        origin = pd.Timestamp(origin.strip())
        u = unit_name.strip().lower()
        if u.startswith("day"):
            return origin + pd.to_timedelta(values, unit="D")
        if u.startswith("hour"):
            return origin + pd.to_timedelta(values, unit="h")
        if u.startswith("min"):
            return origin + pd.to_timedelta(values, unit="m")
        if u.startswith("sec"):
            return origin + pd.to_timedelta(values, unit="s")
        raise ValueError(f"Unsupported numeric time unit: {unit_name}")


def open_nc_dataset_robust(path: Path, decode_times=False, mask_and_scale=True):
    """Load a CF-compliant NetCDF file using available xarray backends."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"NetCDF file does not exist: {path}")

    engines = ["scipy", "h5netcdf", "netcdf4", None]
    errors = []

    def _try_open(candidate):
        for engine in engines:
            try:
                kwargs = dict(decode_times=decode_times, mask_and_scale=mask_and_scale)
                if engine is not None:
                    kwargs["engine"] = engine
                ds = xr.open_dataset(str(candidate), **kwargs)
                ds.load()
                return ds, engine or "xarray-default"
            except Exception as exc:
                errors.append(f"{engine or 'default'}: {type(exc).__name__}: {exc}")
        return None, None

    ds, engine = _try_open(path)
    if ds is not None:
        return ds

    # Fallback for file paths unsupported by a NetCDF backend.
    with tempfile.TemporaryDirectory(prefix="elnino_nc_") as td:
        tmp = Path(td) / "input.nc"
        shutil.copy2(path, tmp)
        ds, engine = _try_open(tmp)
        if ds is not None:
            return ds

    raise OSError(
        "Could not open NetCDF file after trying scipy/h5netcdf/netCDF4 and "
        f"an ASCII temporary-path fallback: {path}\n" + "\n".join(errors)
    )


def read_nc_variable(path: Path, variable: str) -> pd.Series:
    """Read a 1-D climate index variable from a NetCDF file robustly."""
    ds = open_nc_dataset_robust(path, decode_times=False, mask_and_scale=True)
    try:
        if variable not in ds.data_vars:
            # case-insensitive fallback
            matches = [v for v in ds.data_vars if v.upper() == variable.upper()]
            if not matches:
                raise KeyError(f"Variable {variable} not found in {path.name}; variables={list(ds.data_vars)}")
            variable = matches[0]

        da = ds[variable]
        if da.ndim != 1:
            raise ValueError(f"{path.name}:{variable} is not 1-D; shape={da.shape}")
        dim = da.dims[0]
        t = ds[dim]
        vals = np.asarray(da.values, dtype=float)

        # Respect fill/missing values even if backend did not mask them.
        for key in ["_FillValue", "missing_value"]:
            fv = da.attrs.get(key, None)
            if fv is not None:
                try:
                    vals[np.isclose(vals, float(fv), equal_nan=False)] = np.nan
                except Exception:
                    pass
        vals[np.abs(vals) > 1e20] = np.nan

        if np.issubdtype(np.asarray(t.values).dtype, np.datetime64):
            dates = pd.to_datetime(t.values)
        else:
            units = t.attrs.get("units")
            calendar = t.attrs.get("calendar", "standard")
            if units is None:
                raise ValueError(f"No time units found for {path.name}:{dim}")
            dates = _parse_time_numeric(np.asarray(t.values), units, calendar)

        s = pd.Series(vals, index=pd.DatetimeIndex(dates), name=variable.upper())
        return clean_series(s)
    finally:
        ds.close()


def discover_input_files():
    """Find exactly one NetCDF file for each required index.

    Internal NetCDF variable names are authoritative. If more than one file
    contains the same target variable, stop instead of silently choosing an
    arbitrary copy such as pna.nc versus pna(3).nc.
    """
    nc_files = sorted(INPUT_DIR.glob("*.nc"))
    if not nc_files:
        raise FileNotFoundError(f"No .nc files found in {INPUT_DIR}")

    wanted = ["NINO34", "SOI", "PDO", "PNA", "NAO", "AO"]
    hits = {k: [] for k in wanted}

    print("\nScanning ALL NetCDF files in:", INPUT_DIR)
    for path in nc_files:
        try:
            ds = open_nc_dataset_robust(path, decode_times=False, mask_and_scale=True)
            vars_upper = {v.upper(): v for v in ds.data_vars}
            found_here = []
            for key in wanted:
                if key in vars_upper:
                    hits[key].append(path)
                    found_here.append(key)
            ds.close()
            print(f"  {path.name}: variables={list(vars_upper)}" + (f" -> {found_here}" if found_here else ""))
        except Exception as exc:
            print(f"  WARNING: could not inspect {path.name}: {exc}")

    mapping = {}
    for key in wanted:
        unique = []
        seen = set()
        for path in hits[key]:
            rp = str(path.resolve())
            if rp not in seen:
                unique.append(path)
                seen.add(rp)
        if len(unique) > 1:
            names = "\n  ".join(p.name for p in unique)
            raise RuntimeError(
                f"Multiple NetCDF files contain variable {key}. Remove old copies or keep only the intended file:\n  {names}"
            )
        if len(unique) == 1:
            mapping[key] = unique[0]

    missing = [k for k in wanted if k not in mapping]
    if missing:
        raise FileNotFoundError(
            "Missing required climate-index NetCDF variables/files: " + ", ".join(missing) +
            f"\nPut exactly one file for each of the six indices inside: {INPUT_DIR}"
        )

    print("\nDetected input mapping:")
    for key in wanted:
        print(f"  {key:7s} -> {mapping[key].name}")
    return mapping


def validate_input_frequencies(data):
    """Validate the temporal structure expected by this workflow."""
    report = {}
    for key, s in data.items():
        ss = clean_series(s)
        if len(ss) < 3:
            raise ValueError(f"{key} contains too few valid observations.")
        dt = np.diff(ss.index.values).astype("timedelta64[D]").astype(float)
        med = float(np.nanmedian(dt))
        report[key] = med
        if key == "NINO34":
            if not (6.0 <= med <= 8.0):
                raise ValueError(
                    f"NINO34 is expected to be weekly (~7 days), but median spacing is {med:.1f} days."
                )
        else:
            if not (27.0 <= med <= 32.0):
                raise ValueError(
                    f"{key} is expected to be monthly (~28-31 days), but median spacing is {med:.1f} days."
                )
    print("\nInput-frequency validation:")
    for key in ["NINO34", "SOI", "PDO", "PNA", "NAO", "AO"]:
        print(f"  {key:7s}: median spacing = {report[key]:.1f} days")
    return report


def nino_weekly_to_monthly_primary(weekly: pd.Series) -> pd.Series:
    """
    Convert weekly OISST NINO3.4 to calendar-month means by interpolating the
    weekly time series to a daily grid, then averaging daily values by month.
    This reduces arbitrary dependence on how 4/5 weekly timestamps fall in a month.
    """
    weekly = clean_series(weekly)
    daily_index = pd.date_range(weekly.index.min().normalize(), weekly.index.max().normalize(), freq="D")
    union = weekly.reindex(weekly.index.union(daily_index)).sort_index().interpolate(method="time")
    daily = union.reindex(daily_index)
    monthly = daily.resample("MS").mean().dropna()
    monthly.name = "NINO34"
    return monthly


def nino_weekly_to_monthly_simple(weekly: pd.Series) -> pd.Series:
    out = clean_series(weekly).resample("MS").mean().dropna()
    out.name = "NINO34_SIMPLE"
    return out


def to_monthly(s: pd.Series) -> pd.Series:
    return clean_series(s).resample("MS").mean().dropna()


def centered_3m(s: pd.Series) -> pd.Series:
    return clean_series(s).rolling(3, center=True, min_periods=3).mean().dropna()


def trailing_3m(s: pd.Series) -> pd.Series:
    """Three-month trailing mean using only month t and the two preceding months.

    This is used for lead/lag analysis so the predictor at month t never
    contains information from month t+1.
    """
    return clean_series(s).rolling(3, center=False, min_periods=3).mean().dropna()


def djf_mean(monthly: pd.Series) -> pd.Series:
    """Return DJF mean indexed by Jan/Feb calendar year (e.g., DJF 1998 = Dec 1997-Jan-Feb 1998)."""
    s = clean_series(monthly)
    rows = {}
    years = range(s.index.year.min() + 1, s.index.year.max() + 1)
    for y in years:
        dates = [pd.Timestamp(y - 1, 12, 1), pd.Timestamp(y, 1, 1), pd.Timestamp(y, 2, 1)]
        if all(d in s.index for d in dates):
            vals = [s.loc[d] for d in dates]
            if np.all(np.isfinite(vals)):
                rows[y] = float(np.mean(vals))
    return pd.Series(rows, dtype=float)


def months_mean_by_year(s: pd.Series, months) -> pd.Series:
    s = clean_series(s)
    out = {}
    for y in sorted(set(s.index.year)):
        z = s[(s.index.year == y) & s.index.month.isin(months)]
        if len(z) == len(months) and z.notna().all():
            out[y] = float(z.mean())
    return pd.Series(out, dtype=float)


def seasonal_nino34(monthly_nino: pd.Series):
    """Derive seasonal ENSO indices only from the supplied NINO34 input."""
    monthly_nino = clean_series(monthly_nino)
    return {
        "DJF": djf_mean(monthly_nino),
        "JJA": months_mean_by_year(monthly_nino, [6, 7, 8]),
        "SON": months_mean_by_year(monthly_nino, [9, 10, 11]),
    }


def nino34_class(v):
    """Study-defined DJF Niño-3.4 magnitude bins; NOT official ENSO episode classes."""
    if v <= -0.5:
        return "Cold Niño-3.4"
    if v < 0.5:
        return "Neutral"
    if v < 1.0:
        return "Weak warm Niño-3.4"
    if v < 1.5:
        return "Moderate warm Niño-3.4"
    if v < 2.0:
        return "Strong warm Niño-3.4"
    return "Very strong warm Niño-3.4"


def pearson_clean(x, y):
    d = pd.concat([pd.Series(x).rename("x"), pd.Series(y).rename("y")], axis=1).dropna()
    if len(d) < 3:
        return np.nan, np.nan, len(d)
    r, p = stats.pearsonr(d.x, d.y)
    return float(r), float(p), int(len(d))


def circular_shift_corr_pvalue(x, y):
    x = np.asarray(x, float); y = np.asarray(y, float)
    m = np.isfinite(x) & np.isfinite(y); x = x[m]; y = y[m]
    n = len(x)
    if n < 4:
        return np.nan
    obs = abs(np.corrcoef(x, y)[0, 1])
    null = []
    for k in range(1, n):
        rr = np.corrcoef(x, np.roll(y, k))[0, 1]
        if np.isfinite(rr): null.append(abs(rr))
    null = np.asarray(null)
    return float((1 + np.sum(null >= obs)) / (len(null) + 1))


def _make_blocks(n, block_length):
    idx = np.arange(n)
    return [idx[i:min(i + block_length, n)] for i in range(0, n, block_length)]


def block_permutation_corr_pvalue(x, y, block_length=3, n_perm=N_BLOCK_PERM, seed=123, batch_size=1000):
    """
    Two-sided correlation null test using contiguous-block permutation with a
    random circular offset. This preserves local serial dependence much better
    than iid permutation while retaining short-term serial dependence.
    """
    x = np.asarray(x, float); y = np.asarray(y, float)
    m = np.isfinite(x) & np.isfinite(y); x = x[m]; y = y[m]
    n = len(x)
    if n < 8:
        return np.nan
    block_length = int(max(2, min(block_length, n // 2)))
    rng = np.random.default_rng(seed)
    obs = abs(np.corrcoef(x, y)[0, 1])
    base = np.arange(n, dtype=int)
    count = 1
    done = 0
    x0 = x - np.mean(x)
    sx = np.sum(x0 * x0)
    while done < int(n_perm):
        b = min(int(batch_size), int(n_perm) - done)
        idx = np.empty((b, n), dtype=int)
        offsets = rng.integers(0, n, size=b)
        for j, offset in enumerate(offsets):
            yr_idx = np.roll(base, int(offset))
            blocks = [yr_idx[i:i + block_length] for i in range(0, n, block_length)]
            order = rng.permutation(len(blocks))
            idx[j] = np.concatenate([blocks[i] for i in order])
        yp = y[idx]
        yp0 = yp - yp.mean(axis=1, keepdims=True)
        den = np.sqrt(sx * np.sum(yp0 * yp0, axis=1))
        with np.errstate(divide="ignore", invalid="ignore"):
            rr = (yp0 @ x0) / den
        good = np.isfinite(rr)
        count += int(np.sum(np.abs(rr[good]) >= obs))
        done += b
    return count / (int(n_perm) + 1)


def moving_block_bootstrap_corr_ci(x, y, block_length=3, n_boot=N_BOOT, seed=42):
    x = np.asarray(x, float); y = np.asarray(y, float)
    m = np.isfinite(x) & np.isfinite(y); x = x[m]; y = y[m]
    n = len(x)
    rng = np.random.default_rng(seed)
    vals = []
    starts = np.arange(n)
    for _ in range(n_boot):
        idx = []
        while len(idx) < n:
            s = int(rng.choice(starts))
            idx.extend([(s + j) % n for j in range(block_length)])
        idx = np.asarray(idx[:n])
        rr = np.corrcoef(x[idx], y[idx])[0, 1]
        if np.isfinite(rr): vals.append(rr)
    vals = np.asarray(vals)
    return [float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))]


def benjamini_hochberg(p_values):
    p = np.asarray(p_values, float)
    q = np.full_like(p, np.nan)
    valid = np.isfinite(p)
    pv = p[valid]
    if not len(pv): return q
    order = np.argsort(pv); ranked = pv[order]; m = len(ranked)
    adj = ranked * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    adj = np.clip(adj, 0, 1)
    back = np.empty_like(adj); back[order] = adj; q[valid] = back
    return q


def ols_hac(y, X, names, max_lag=None):
    y = np.asarray(y, float); X = np.asarray(X, float)
    A = np.column_stack([np.ones(len(y)), X])
    beta, *_ = np.linalg.lstsq(A, y, rcond=None)
    resid = y - A @ beta
    n, k = A.shape; dof = n - k
    inv = np.linalg.pinv(A.T @ A)
    if max_lag is None:
        max_lag = int(np.floor(4 * (max(n, 1) / 100.0) ** (2 / 9)))
    max_lag = int(np.clip(max_lag, 1, max(n - 1, 1)))
    S = np.zeros((k, k))
    for t in range(n):
        xt = A[t][:, None]; S += resid[t] ** 2 * (xt @ xt.T)
    for lag in range(1, max_lag + 1):
        w = 1 - lag / (max_lag + 1.0)
        G = np.zeros((k, k))
        for t in range(lag, n):
            G += resid[t] * resid[t-lag] * np.outer(A[t], A[t-lag])
        S += w * (G + G.T)
    cov = (n / max(dof, 1)) * inv @ S @ inv
    se = np.sqrt(np.clip(np.diag(cov), 0, None))
    tt = beta / np.where(se > 0, se, np.nan)
    pp = 2 * stats.t.sf(np.abs(tt), df=max(dof, 1))
    fitted = A @ beta
    sse = float(np.sum((y-fitted)**2)); sst = float(np.sum((y-y.mean())**2))
    r2 = 1 - sse/sst if sst > 0 else np.nan
    return {"names":["const"]+list(names), "beta":beta, "se":se, "p":pp, "r2":r2, "n":n, "max_lag":max_lag}


def expanding_window_linear(years, x, y, min_train=15):
    years=np.asarray(years,int); x=np.asarray(x,float); y=np.asarray(y,float)
    order=np.argsort(years); years=years[order]; x=x[order]; y=y[order]
    pred=np.full(len(y), np.nan)
    for i, yr in enumerate(years):
        m=years<yr
        if m.sum() < min_train or np.std(x[m]) == 0: continue
        sl, ic, *_ = stats.linregress(x[m], y[m])
        pred[i] = sl*x[i]+ic
    m=np.isfinite(pred)
    if m.sum()<3: return pred, {"r2":np.nan,"rmse":np.nan,"mae":np.nan,"r":np.nan,"n":int(m.sum())}
    yy=y[m]; pp=pred[m]
    sse=np.sum((yy-pp)**2); sst=np.sum((yy-yy.mean())**2)
    return pred, {"r2":float(1-sse/sst),"rmse":float(np.sqrt(np.mean((yy-pp)**2))),"mae":float(np.mean(np.abs(yy-pp))),"r":float(np.corrcoef(yy,pp)[0,1]),"n":int(m.sum())}


def run_analysis(data):
    """Run the complete analysis using only the six supplied NetCDF indices."""
    nino_weekly = data["NINO34"]
    nino = nino_weekly_to_monthly_primary(nino_weekly)
    nino_simple = nino_weekly_to_monthly_simple(nino_weekly)
    n34_3m = centered_3m(nino)
    n34_3m_trailing = trailing_3m(nino)
    monthly = {k: to_monthly(v) for k, v in data.items() if k != "NINO34"}

    seasonal = seasonal_nino34(nino)
    nino_djf, nino_jja, nino_son = seasonal["DJF"], seasonal["JJA"], seasonal["SON"]

    out = {
        "method_version": "standalone_seasonal_nino34",
        "enso_index": "Seasonal means derived from the supplied weekly NINO34 series",
        "monthly_lag_predictor": "Trailing 3-month Niño-3.4 mean (t-2, t-1, t); no future-month information",
        "file_coverage": {},
        "seasonal_nino34_coverage": {
            k: [int(v.index.min()), int(v.index.max()), int(len(v))] if len(v) else [None, None, 0]
            for k, v in seasonal.items()
        },
    }
    for k, sr in {"NINO34": nino, **monthly}.items():
        out["file_coverage"][k] = [str(sr.index.min().date()), str(sr.index.max().date()), int(len(sr))]

    # Onset slope March-August every year.
    onset = {}
    for yr in sorted(set(nino.index.year)):
        z = nino[(nino.index.year == yr) & (nino.index.month >= 3) & (nino.index.month <= 8)]
        if len(z) == 6:
            sl, ic, rr, pp, se = stats.linregress(np.arange(6), z.values)
            onset[int(yr)] = {
                "mar": float(z.iloc[0]), "aug": float(z.iloc[-1]),
                "delta": float(z.iloc[-1] - z.iloc[0]), "slope": float(sl)
            }
    if 2026 in onset:
        slopes = pd.Series({y: d["slope"] for y, d in onset.items()})
        deltas = pd.Series({y: d["delta"] for y, d in onset.items()})
        onset[2026]["slope_rank_desc"] = int(slopes.rank(ascending=False, method="min").loc[2026])
        onset[2026]["delta_rank_desc"] = int(deltas.rank(ascending=False, method="min").loc[2026])
        onset[2026]["n_years"] = int(len(slopes))
    out["onset"] = onset

    # Weekly -> monthly sensitivity.
    cc = pd.concat([nino.rename("primary"), nino_simple.rename("simple")], axis=1).dropna()
    out["monthly_aggregation_sensitivity"] = {
        "mean_abs_difference_C": float(np.mean(np.abs(cc.primary - cc.simple))),
        "max_abs_difference_C": float(np.max(np.abs(cc.primary - cc.simple))),
    }

    # Niño-3.4 / SOI monthly coupling.
    ns = pd.concat([nino.rename("NINO34"), monthly["SOI"].rename("SOI")], axis=1, sort=True).dropna()
    r, p = stats.pearsonr(ns.NINO34, ns.SOI)
    out["nino34_soi"] = {
        "r": float(r), "p_naive": float(p),
        "p_circular": circular_shift_corr_pvalue(ns.NINO34, ns.SOI), "n": int(len(ns))
    }

    # PDO March-July mean by developing year.
    pdo_marjul = months_mean_by_year(monthly["PDO"], [3, 4, 5, 6, 7])
    out["pdo_mar_jul"] = {str(int(y)): float(v) for y, v in pdo_marjul.items()}

    # DJF atmospheric indices and concurrent DJF Niño-3.4 correlations.
    djf_atm = {k: djf_mean(monthly[k]) for k in ["PNA", "NAO", "AO"]}
    djf_corr = {}
    block_ps = []
    circ_ps = []
    for i, k in enumerate(["PNA", "NAO", "AO"]):
        d = pd.concat([nino_djf.rename("NINO34_DJF"), djf_atm[k].rename(k)], axis=1).dropna()
        rr, pp = stats.pearsonr(d.NINO34_DJF, d[k])
        pc = circular_shift_corr_pvalue(d.NINO34_DJF, d[k])
        pb = block_permutation_corr_pvalue(d.NINO34_DJF, d[k], block_length=3, seed=500 + i)
        djf_corr[k] = {
            "r": float(rr), "p_naive": float(pp), "p_circular": float(pc),
            "p_block3": float(pb), "n": int(len(d))
        }
        block_ps.append(pb)
        circ_ps.append(pc)
    q_block = benjamini_hochberg(block_ps)
    q_circ = benjamini_hochberg(circ_ps)
    for i, k in enumerate(["PNA", "NAO", "AO"]):
        djf_corr[k]["q_fdr3_block"] = float(q_block[i])
        djf_corr[k]["q_fdr3_circular"] = float(q_circ[i])
    out["djf_nino34_correlations"] = djf_corr

    # Descriptive DJF Niño-3.4 magnitude groups (study-defined; not official ENSO classes).
    cats = nino_djf.map(nino34_class)
    comp = {}
    for k in ["PNA", "NAO", "AO"]:
        d = pd.concat([cats.rename("category"), djf_atm[k].rename(k)], axis=1).dropna()
        comp[k] = {}
        for cat, g in d.groupby("category"):
            comp[k][cat] = {
                "n": int(len(g)), "mean": float(g[k].mean()),
                "sd": float(g[k].std(ddof=1)) if len(g) > 1 else None
            }
    out["djf_composites"] = comp

    # PDO modulation: developing-year March-July PDO aligned to following DJF.
    pdo_context = pdo_marjul.copy()
    pdo_context.index = pdo_context.index + 1
    X = pd.concat([
        nino_djf.rename("NINO34_DJF"), pdo_context.rename("PDO"), djf_atm["PNA"].rename("PNA")
    ], axis=1).dropna()
    X["NINO34_c"] = X.NINO34_DJF - X.NINO34_DJF.mean()
    X["PDO_c"] = X.PDO - X.PDO.mean()
    X["INT"] = X.NINO34_c * X.PDO_c
    model = ols_hac(X.PNA, X[["NINO34_c", "PDO_c", "INT"]], ["NINO34_c", "PDO_c", "INT"])
    pdo_q = X["PDO"].quantile([0.25, 0.50, 0.75])
    out["pdo_modulation"] = {
        "interaction_beta": float(model["beta"][-1]),
        "interaction_p_hac": float(model["p"][-1]),
        "r2": float(model["r2"]), "n": int(model["n"]), "hac_max_lag": int(model["max_lag"]),
        "coefficients": {name: float(beta) for name, beta in zip(model["names"], model["beta"])},
        "coefficient_p_hac": {name: float(pv) for name, pv in zip(model["names"], model["p"])},
        "nino34_mean": float(X.NINO34_DJF.mean()),
        "pdo_mean": float(X.PDO.mean()),
        "pdo_q25": float(pdo_q.loc[0.25]), "pdo_q50": float(pdo_q.loc[0.50]), "pdo_q75": float(pdo_q.loc[0.75]),
    }
    for label, sub in [("positive", X[X.PDO > 0]), ("nonpositive", X[X.PDO <= 0])]:
        if len(sub) >= 3:
            out["pdo_modulation"][f"r_nino34_pna_pdo_{label}"] = float(stats.pearsonr(sub.NINO34_DJF, sub.PNA)[0])
            out["pdo_modulation"][f"n_{label}"] = int(len(sub))

    # Pinatubo sensitivity and block robustness for DJF Niño-3.4 vs PNA.
    base = pd.concat([nino_djf.rename("NINO34_DJF"), djf_atm["PNA"].rename("PNA")], axis=1).dropna()
    excl = base.drop(index=PINATUBO_DJF_LABEL_YEAR, errors="ignore")
    robustness = {
        "full_r": float(stats.pearsonr(base.NINO34_DJF, base.PNA)[0]),
        "exclude_1992_r": float(stats.pearsonr(excl.NINO34_DJF, excl.PNA)[0]),
        "blocks": {}
    }
    for L in ROBUST_BLOCK_LENGTHS:
        robustness["blocks"][str(L)] = {
            "full_ci95": moving_block_bootstrap_corr_ci(base.NINO34_DJF, base.PNA, L, N_BOOT, 1000 + L),
            "exclude_1992_ci95": moving_block_bootstrap_corr_ci(excl.NINO34_DJF, excl.PNA, L, N_BOOT, 2000 + L),
            "full_p_block": float(block_permutation_corr_pvalue(base.NINO34_DJF, base.PNA, L, N_BLOCK_PERM, 3000 + L)),
        }
    out["robustness"] = robustness

    # Developing-year JJA Niño-3.4 -> following DJF Niño-3.4 persistence benchmark.
    following_djf = pd.Series({int(y - 1): float(v) for y, v in nino_djf.items()}, name="DJF_NINO34")
    train = pd.concat([nino_jja.rename("JJA_NINO34"), following_djf], axis=1).dropna()
    train = train[train.index < 2026]
    years = train.index.to_numpy(int)
    xx = train.JJA_NINO34.to_numpy(float)
    yy = train.DJF_NINO34.to_numpy(float)
    sl, ic, rr, pp, se = stats.linregress(xx, yy)
    pred_cv, cv = expanding_window_linear(years, xx, yy, 15)
    out["nino34_persistence"] = {
        "slope": float(sl), "intercept": float(ic), "in_sample_r": float(rr), "in_sample_p": float(pp),
        "training_range": [float(xx.min()), float(xx.max())], "hindcast": cv
    }
    if 2026 in nino_jja.index:
        x0 = float(nino_jja.loc[2026])
        y0 = float(sl * x0 + ic)
        resid = yy - (sl * xx + ic)
        n = len(xx)
        sres = float(np.sqrt(np.sum(resid ** 2) / (n - 2)))
        xbar = xx.mean()
        sxx = np.sum((xx - xbar) ** 2)
        tcrit = stats.t.ppf(.975, n - 2)
        half = float(tcrit * sres * np.sqrt(1 + 1 / n + (x0 - xbar) ** 2 / sxx))
        out["nino34_persistence"]["2026"] = {
            "jja_nino34": x0, "djf_point": y0, "pi95": [y0 - half, y0 + half],
            "outside_training_range": bool(x0 < xx.min() or x0 > xx.max())
        }

    # Seasonal leads: JJA/SON Niño-3.4 in developing year -> following DJF atmosphere;
    # concurrent DJF Niño-3.4 -> DJF atmosphere. Use block-permutation FDR as primary.
    leadtab = {}
    block_ps = []
    circ_ps = []
    refs = []
    seed_counter = 0
    for k in ["PNA", "NAO", "AO"]:
        target = djf_atm[k]
        leadtab[k] = {}
        for lab, pred in [("JJA(-1)", nino_jja), ("SON(-1)", nino_son), ("DJF(0)", nino_djf)]:
            pser = pred.copy()
            if lab != "DJF(0)":
                pser.index = pser.index + 1
            d = pd.concat([pser.rename("x"), target.rename("y")], axis=1).dropna()
            rr, pp = stats.pearsonr(d.x, d.y)
            pc = circular_shift_corr_pvalue(d.x, d.y)
            pb = block_permutation_corr_pvalue(d.x, d.y, block_length=3, seed=8000 + seed_counter)
            leadtab[k][lab] = {
                "r": float(rr), "p_naive": float(pp), "p_circular": float(pc),
                "p_block3": float(pb), "n": int(len(d))
            }
            refs.append((k, lab)); block_ps.append(pb); circ_ps.append(pc)
            seed_counter += 1
    q_block = benjamini_hochberg(block_ps)
    q_circ = benjamini_hochberg(circ_ps)
    for i, (k, lab) in enumerate(refs):
        leadtab[k][lab]["q_fdr9_block"] = float(q_block[i])
        leadtab[k][lab]["q_fdr9_circular"] = float(q_circ[i])
    out["seasonal_lead_correlations"] = leadtab

    # Monthly lag correlations: trailing 3-month Niño-3.4 mean at t versus atmosphere(t + lag).
    # The trailing mean uses only t-2, t-1 and t, preventing future-month leakage.
    # Monthly records are long enough for circular-shift resolution; FDR across 39 tests.
    lag_results = {k: {} for k in ["PNA", "NAO", "AO"]}
    lag_pvals = []
    lag_refs = []
    for k in ["PNA", "NAO", "AO"]:
        for lag in range(-6, 7):
            atm_shifted = monthly[k].shift(-lag)
            d = pd.concat([n34_3m_trailing.rename("N34_3M_TRAILING"), atm_shifted.rename(k)], axis=1, sort=True).dropna()
            if len(d) >= 12:
                rr, pp = stats.pearsonr(d.N34_3M_TRAILING, d[k])
                pc = circular_shift_corr_pvalue(d.N34_3M_TRAILING, d[k])
                lag_results[k][str(lag)] = {
                    "r": float(rr), "p_naive": float(pp), "p_circular": float(pc), "n": int(len(d))
                }
                lag_pvals.append(pc); lag_refs.append((k, str(lag)))
            else:
                lag_results[k][str(lag)] = {"r": None, "p_naive": None, "p_circular": None, "n": int(len(d))}
    lag_q = benjamini_hochberg(lag_pvals)
    for (k, lag), qq in zip(lag_refs, lag_q):
        lag_results[k][lag]["q_fdr39"] = float(qq)
    out["monthly_lag_correlations"] = lag_results

    ctx = {
        "nino_weekly": clean_series(nino_weekly), "nino": nino, "nino_simple": nino_simple,
        "n34_3m": n34_3m, "n34_3m_trailing": n34_3m_trailing,
        "monthly": monthly, "seasonal_nino34": seasonal,
        "djf_atm": djf_atm, "pdo_marjul": pdo_marjul, "cats": cats,
    }
    return out, ctx


def _apply_publication_style():
    """Configure figure fonts and line styles."""
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "DejaVu Sans", "Liberation Sans"],
        "font.size": 9.5,
        "axes.titlesize": 11.5,
        "axes.labelsize": 9.6,
        "axes.labelpad": 5.0,
        "axes.linewidth": 0.9,
        "axes.grid": True,
        "grid.alpha": 0.20,
        "grid.linewidth": 0.55,
        "legend.frameon": False,
        "legend.fontsize": 8.4,
        "xtick.labelsize": 8.5,
        "ytick.labelsize": 8.5,
        "figure.dpi": 120,
        "savefig.dpi": DPI,
        "savefig.bbox": "tight",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


def _panel_title(ax, text):
    ax.set_title(text, loc="left", fontweight="bold", pad=8)



WARM = "#c92f35"
COOL = "#27649f"
ACC = "#e07a00"
GREEN = "#2f7a4d"
PURPLE = "#6b3fa0"
BROWN = "#8d5a4b"
NEUT = "#8a8a8a"
LIGHT = "#d9d9d9"

def save_figure(fig):
    """Export PDF and LZW-compressed TIFF at the configured resolution."""
    out_dir = Path(FIGURE_DIR)
    out_dir.mkdir(parents=True, exist_ok=True)
    label = FIGURE_LABEL
    for ext, fmt in [("pdf", "pdf"), ("tif", "tiff")]:
        target = out_dir / f"{label}.{ext}"
        options = dict(format=fmt, dpi=DPI, bbox_inches="tight", pad_inches=0.22, facecolor="white")
        if fmt == "tiff":
            options["pil_kwargs"] = {"compression": "tiff_lzw"}
        fig.savefig(target, **options)
        if fmt == "tiff":
            # Journal raster delivery: lossless LZW compression, RGB colour mode.
            from PIL import Image
            with Image.open(target) as src:
                if src.mode != "RGB":
                    rgb = src.convert("RGB")
                else:
                    rgb = src.copy()
            tmp_rgb = target.with_name(target.stem + ".rgb.tmp.tif")
            try:
                rgb.save(tmp_rgb, compression="tiff_lzw", dpi=(DPI, DPI))
                tmp_rgb.replace(target)
            finally:
                rgb.close()
                if tmp_rgb.exists():
                    tmp_rgb.unlink()
        print("Saved", target)
    plt.close(fig)


def load_and_analyse(input_dir=None):
    """Load the six climate-index series and calculate derived statistics."""
    global INPUT_DIR
    if input_dir is not None:
        INPUT_DIR = Path(input_dir).resolve()
    file_map = discover_input_files()
    data = {key: read_nc_variable(path, key) for key, path in file_map.items()}
    validate_input_frequencies(data)
    out, ctx = run_analysis(data)
    return out, ctx


def run_single(label, plot, argv=None):
    """Calculate statistics and export one figure."""
    import argparse
    global FIGURE_DIR, DPI, FIGURE_LABEL
    parser = argparse.ArgumentParser(description=f"Reproduce {label} from the 6 climate-index NetCDF files")
    parser.add_argument("--data", type=Path, default=HERE / "data", help="Directory containing the six NetCDF files")
    parser.add_argument("--output", type=Path, default=HERE / "outputs", help="Directory for PDF and TIFF")
    parser.add_argument("--dpi", type=int, default=900, help="Raster TIFF resolution (default: 900)")
    args = parser.parse_args(argv)
    if not 100 <= args.dpi <= 1200:
        parser.error("--dpi must be between 100 and 1200")
    FIGURE_DIR, DPI, FIGURE_LABEL = args.output.resolve(), args.dpi, label
    out, ctx = load_and_analyse(args.data)
    _apply_publication_style()
    plot(out,ctx)
    return out
