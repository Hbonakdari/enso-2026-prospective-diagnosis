# -*- coding: utf-8 -*-
"""Figure_S02: Monthly lead-lag correlations."""
from __future__ import annotations

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from enso_shared_analysis import (
    run_single,
    save_figure,
    GREEN,
    PURPLE,
    BROWN,
)

def plot(out,ctx):
    nino_weekly = ctx["nino_weekly"]
    nino = ctx["nino"]
    n34 = ctx["n34_3m"]
    M = ctx["monthly"]
    seasonal = ctx["seasonal_nino34"]
    pdo_marjul = ctx["pdo_marjul"]
    djf_atm = pd.DataFrame(ctx["djf_atm"])
    cats = ctx["cats"]

    fig, ax = plt.subplots(figsize=(7.50, 4.80))
    lags = np.arange(-6, 7)
    for k, col in [("PNA", PURPLE), ("NAO", GREEN), ("AO", BROWN)]:
        vals = np.array([out["monthly_lag_correlations"][k][str(int(l))]["r"] for l in lags], float)
        ax.plot(lags, vals, marker="o", lw=1.7, ms=3.7, color=col, label=k)
        sig = [(l, v) for l, v in zip(lags, vals)
               if 0 <= out["monthly_lag_correlations"][k][str(int(l))].get("q_fdr39", 1) < .05]
        if sig:
            sx, sy = zip(*sig)
            ax.scatter(sx, sy, s=72, facecolors="white", edgecolors=col,
                       linewidths=1.25, zorder=6)
    from matplotlib.lines import Line2D
    fdr_handle = Line2D([0], [0], marker="o", linestyle="none", markerfacecolor="white",
                        markeredgecolor="#333333", markeredgewidth=1.1, markersize=6.5,
                        label="FDR q < 0.05")
    handles, labels = ax.get_legend_handles_labels()
    # Single-column legend for circulation indices and significance marker.
    ax.legend(handles + [fdr_handle], labels + ["FDR q < 0.05"],
              loc="upper left", ncol=1, frameon=False, fontsize=8.2,
              handlelength=1.55, columnspacing=.9, borderaxespad=.28)
    ax.axhline(0, color="k", lw=.8)
    ax.axvline(0, color="#777", lw=.8, ls="--")
    ax.set_xticks(lags)
    ax.set_xlim(-6.3, 6.3)
    ax.set_xlabel("Lag (months; + = atmospheric index follows Niño-3.4)")
    ax.set_ylabel("Pearson R")
    ax.set_title("Monthly Niño-3.4 lag correlations", fontweight="bold")
    fig.tight_layout(rect=[0.0, 0.0, 1.0, 0.98])
    save_figure(fig)


if __name__ == "__main__":
    run_single("Figure_S02", plot)
