# -*- coding: utf-8 -*-
"""Figure_06: Historical JJA-to-DJF persistence and extrapolation."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
from enso_shared_analysis import (
    run_single,
    save_figure,
    _panel_title,
    ACC,
)

def plot(out,ctx):
    nino_weekly = ctx["nino_weekly"]
    nino = ctx["nino"]
    n34 = ctx["n34_3m"]
    M = ctx["monthly"]
    seasonal = ctx["seasonal_nino34"]
    pdo_marjul = ctx["pdo_marjul"]
    djf_atm = pd.DataFrame(ctx["djf_atm"])
    cats = ctx["cats"]

    fig, axes = plt.subplots(1, 2, figsize=(11.8, 5.0),
                             gridspec_kw={"width_ratios": [1.25, 1]})
    rj = seasonal["JJA"].dropna()
    rd = seasonal["DJF"].dropna()
    target = pd.Series({int(y - 1): float(v) for y, v in rd.items()}, name="DJF")
    train = pd.concat([rj.rename("JJA"), target], axis=1).dropna()
    train = train[train.index < 2026]

    ax = axes[0]
    ax.scatter(train.JJA, train.DJF, s=40, color="#4b83b6", edgecolors="#333",
               linewidths=.4, alpha=.84)
    sl = out["nino34_persistence"]["slope"]
    ic = out["nino34_persistence"]["intercept"]
    xg = np.linspace(train.JJA.min() - .2, train.JJA.max() + .2, 300)
    yg = sl * xg + ic
    ax.plot(xg, yg, color="k", lw=1.7)
    xxv = train.JJA.values
    yyv = train.DJF.values
    resid = yyv - (sl * xxv + ic)
    n = len(xxv)
    sres = np.sqrt(np.sum(resid**2) / (n - 2))
    xbar = xxv.mean()
    sxx = np.sum((xxv - xbar)**2)
    tc = stats.t.ppf(.975, n - 2)
    half = tc * sres * np.sqrt(1 + 1 / n + (xg - xbar)**2 / sxx)
    ax.fill_between(xg, yg - half, yg + half, color="#d0d0d0", alpha=.38)
    for yr in [1982, 1991, 1997, 2015]:
        if yr in train.index:
            ax.scatter(train.loc[yr, "JJA"], train.loc[yr, "DJF"], s=75,
                       color="#666666", edgecolors="k", linewidths=.5, zorder=7)
            ax.annotate(str(yr), (train.loc[yr, "JJA"], train.loc[yr, "DJF"]),
                        textcoords="offset points", xytext=(5, -12),
                        color="#555555", fontweight="bold", fontsize=7.0)
    z = out["nino34_persistence"].get("2026", {})
    if z:
        ax.scatter(z["jja_nino34"], z["djf_point"], s=175, marker="*", color=ACC,
                   edgecolors="k", linewidths=.7, zorder=9)
        lo, hi = z["pi95"]
        ax.errorbar(z["jja_nino34"], z["djf_point"],
                    yerr=[[z["djf_point"] - lo], [hi - z["djf_point"]]],
                    fmt="none", ecolor=ACC, capsize=4, lw=1.3)
        ax.annotate("2026", (z["jja_nino34"], z["djf_point"]),
                    textcoords="offset points", xytext=(-7, 6), ha="right",
                    fontsize=7.0, fontweight="bold", color=ACC, annotation_clip=True)
    ax.axhline(0, color="k", lw=.75)
    ax.axvline(0, color="k", lw=.75)
    cv = out["nino34_persistence"]["hindcast"]
    ax.text(.03, .97,
            f"R² = {cv['r2']:.2f}",
            transform=ax.transAxes, ha="left", va="top", fontsize=7.8)
    ax.set_xlabel("JJA Niño-3.4 anomaly (°C) of developing year")
    ax.set_ylabel("Following DJF Niño-3.4 anomaly (°C)")
    _panel_title(ax, "(a) JJA-to-DJF Niño-3.4 persistence")

    ax = axes[1]
    ax.hist(train.JJA, bins=14, color="#6d94b9", alpha=.88, edgecolor="white")
    trlo, trhi = out["nino34_persistence"]["training_range"]
    x0 = z.get("jja_nino34", np.nan) if z else np.nan
    if np.isfinite(x0):
        ax.axvline(x0, color=ACC, lw=2.0)
        ax.annotate(f"2026 {x0:+.2f}", xy=(x0, ax.get_ylim()[1] * .70), xycoords="data",
                    xytext=(.96, .92), textcoords="axes fraction",
                    ha="right", va="top", fontsize=7.2, color=ACC, fontweight="bold",
                    arrowprops=dict(arrowstyle="-", color=ACC, lw=.8), annotation_clip=True)
        xmin = min(float(train.JJA.min()) - .15, x0 - .15)
        xmax = max(float(train.JJA.max()) + .15, x0 + .15)
        ax.set_xlim(xmin, xmax)
    ax.text(.03, .97, f"Historical range: {trlo:+.2f} to {trhi:+.2f}",
            transform=ax.transAxes, ha="left", va="top", fontsize=7.6, color="#555555")
    ax.set_xlabel("JJA Niño-3.4 anomaly (°C)")
    ax.set_ylabel("Number of years")
    _panel_title(ax, "(b) 2026 relative to the historical JJA range")
    fig.tight_layout()
    save_figure(fig)


if __name__ == "__main__":
    run_single("Figure_06", plot)
